"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULT_SETTINGS = {
    highlight: true,
    highlightMode: "neighbors",
    direction: "both",
    highlightColor: "#f59e0b",
    flowAnimation: false,
    flowDuration: 1.5,
    buildDuration: 8,
    theme: "auto",
    disabledSites: []
  };
  var KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.sync.get(KEYS);
    const merged = { ...DEFAULT_SETTINGS, ...stored };
    if (merged.highlightMode === "off") {
      merged.highlight = typeof stored.highlight === "boolean" ? stored.highlight : false;
      merged.highlightMode = DEFAULT_SETTINGS.highlightMode;
    }
    return merged;
  }
  function watchSettings(cb) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !KEYS.some((k) => k in changes)) return;
      loadSettings().then(cb);
    });
  }
  function isSiteEnabled(s, host) {
    return !s.disabledSites.includes(host);
  }
  var DIAGRAM_HINT_SELECTOR = [
    'section[data-type="mermaid"]',
    'pre[lang="mermaid"]',
    "code.language-mermaid",
    "pre.mermaid",
    'svg[id^="mermaid"][aria-roledescription]',
    ".mermaid svg[aria-roledescription]"
  ].join(",");

  // src/detector.ts
  if (!window.__mermaidLensDetector) {
    window.__mermaidLensDetector = true;
    void start();
  }
  async function start() {
    const host = location.hostname;
    let enabled = isSiteEnabled(await loadSettings(), host);
    let requested = false;
    let timer = 0;
    const send = (msg) => chrome.runtime.sendMessage(msg).catch(() => {
    });
    const check = () => {
      timer = 0;
      if (requested || window.__mermaidLens) return;
      if (!document.querySelector(DIAGRAM_HINT_SELECTOR)) return;
      if (!enabled) {
        send({ type: "ml:status", count: 0, enabled: false });
        return;
      }
      requested = true;
      observer.disconnect();
      chrome.runtime.sendMessage({ type: "ml:inject" }).then((res) => {
        if (res?.ok) return;
        throw new Error(res?.error ?? "no response from service worker");
      }).catch((err) => {
        console.warn("[Mermaid Lens] could not load the enhancer:", err);
        requested = false;
        observer.observe(document.documentElement, { childList: true, subtree: true });
      });
    };
    const observer = new MutationObserver(() => {
      if (!timer) timer = window.setTimeout(check, 250);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    check();
    watchSettings((s) => {
      const next = isSiteEnabled(s, host);
      if (next === enabled) return;
      enabled = next;
      if (enabled && !requested) check();
    });
  }
})();
