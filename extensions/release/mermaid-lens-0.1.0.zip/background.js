"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULT_SETTINGS = {
    highlight: true,
    highlightMode: "neighbors",
    direction: "both",
    highlightColor: "#f59e0b",
    flowAnimation: false,
    flowDuration: 1.5,
    buildDuration: 8,
    theme: "auto",
    disabledSites: []
  };
  var KEYS = Object.keys(DEFAULT_SETTINGS);
  var BUILT_IN_MATCHES = ["https://github.com/*", "https://gist.github.com/*"];
  var ENHANCER_FILES = ["vendor/mermaid.min.js", "enhancer.js"];
  var DIAGRAM_HINT_SELECTOR = [
    'section[data-type="mermaid"]',
    'pre[lang="mermaid"]',
    "code.language-mermaid",
    "pre.mermaid",
    'svg[id^="mermaid"][aria-roledescription]',
    ".mermaid svg[aria-roledescription]"
  ].join(",");

  // src/background.ts
  var EXTRA_SCRIPT_ID = "mermaid-lens-extra-sites";
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (tabId === void 0) return;
    if (msg.type === "ml:inject") {
      chrome.scripting.executeScript({ target: { tabId, frameIds: [sender.frameId ?? 0] }, files: ENHANCER_FILES }).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }
    if (msg.type === "ml:status") {
      const text = !msg.enabled ? "off" : msg.count > 0 ? String(msg.count) : "";
      chrome.action.setBadgeText({ tabId, text }).catch(() => {
      });
      chrome.action.setBadgeBackgroundColor({ tabId, color: msg.enabled ? "#6366f1" : "#6b7280" }).catch(() => {
      });
    }
  });
  async function syncExtraSites() {
    const { origins = [] } = await chrome.permissions.getAll();
    const extra = origins.filter((o) => !BUILT_IN_MATCHES.includes(o));
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [EXTRA_SCRIPT_ID] });
    if (extra.length === 0) {
      if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [EXTRA_SCRIPT_ID] });
      return;
    }
    const script = {
      id: EXTRA_SCRIPT_ID,
      matches: extra,
      js: ["detector.js"],
      runAt: "document_idle",
      persistAcrossSessions: true
    };
    if (existing.length) await chrome.scripting.updateContentScripts([script]);
    else await chrome.scripting.registerContentScripts([script]);
  }
  chrome.runtime.onInstalled.addListener(() => void syncExtraSites());
  chrome.runtime.onStartup.addListener(() => void syncExtraSites());
  chrome.permissions.onAdded.addListener(() => void syncExtraSites());
  chrome.permissions.onRemoved.addListener(() => void syncExtraSites());
})();
