"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULT_SETTINGS = {
    highlight: true,
    highlightMode: "neighbors",
    direction: "both",
    highlightColor: "#f59e0b",
    flowAnimation: false,
    flowDuration: 1.5,
    buildDuration: 8,
    theme: "auto",
    disabledSites: []
  };
  var PALETTE = ["#f59e0b", "#ef4444", "#ec4899", "#a855f7", "#6366f1", "#0ea5e9", "#14b8a6", "#22c55e"];
  var THEME_LABELS = {
    auto: "Match page",
    default: "Default",
    neutral: "Neutral",
    forest: "Forest",
    dark: "Dark",
    neo: "Neo",
    "neo-dark": "Neo dark"
  };
  var KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.sync.get(KEYS);
    const merged = { ...DEFAULT_SETTINGS, ...stored };
    if (merged.highlightMode === "off") {
      merged.highlight = typeof stored.highlight === "boolean" ? stored.highlight : false;
      merged.highlightMode = DEFAULT_SETTINGS.highlightMode;
    }
    return merged;
  }
  function saveSettings(patch) {
    return chrome.storage.sync.set(patch);
  }
  function watchSettings(cb) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !KEYS.some((k) => k in changes)) return;
      loadSettings().then(cb);
    });
  }
  function isSiteEnabled(s, host) {
    return !s.disabledSites.includes(host);
  }
  async function setSiteEnabled(host, enabled) {
    const { disabledSites } = await loadSettings();
    const next = disabledSites.filter((h) => h !== host);
    if (!enabled) next.push(host);
    await saveSettings({ disabledSites: next });
  }
  function isBuiltInHost(host) {
    return host === "github.com" || host === "gist.github.com";
  }
  var ENHANCER_FILES = ["vendor/mermaid.min.js", "enhancer.js"];
  var DIAGRAM_HINT_SELECTOR = [
    'section[data-type="mermaid"]',
    'pre[lang="mermaid"]',
    "code.language-mermaid",
    "pre.mermaid",
    'svg[id^="mermaid"][aria-roledescription]',
    ".mermaid svg[aria-roledescription]"
  ].join(",");

  // src/popup/popup.ts
  var $ = (id) => document.getElementById(id);
  async function main() {
    $("version").textContent = `v${chrome.runtime.getManifest().version}`;
    let settings = await loadSettings();
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tab?.url ? new URL(tab.url) : null;
    const siteToggle = $("site-toggle");
    const runOnce = $("run-once");
    const usable = !!url && /^https?:$/.test(url.protocol);
    const host = usable ? url.hostname : "";
    const pattern = usable ? `${url.protocol}//${host}/*` : "";
    let hasAccess = usable && (isBuiltInHost(host) || await chrome.permissions.contains({ origins: [pattern] }));
    const badge = tab?.id !== void 0 ? await chrome.action.getBadgeText({ tabId: tab.id }).catch(() => "") : "";
    const renderSite = () => {
      const on = hasAccess && isSiteEnabled(settings, host);
      siteToggle.setAttribute("aria-checked", String(on));
      siteToggle.disabled = !usable;
      $("site-name").textContent = usable ? host : "This page";
      const count = Number(badge);
      $("site-status").textContent = !usable ? "Mermaid Lens can\u2019t run on this page" : !hasAccess ? "Off \u2014 turn on to enhance diagrams here" : !on ? "Switched off for this site" : count > 0 ? `${count} diagram${count === 1 ? "" : "s"} enhanced on this page` : "On \u2014 diagrams will be enhanced";
      runOnce.hidden = !usable || hasAccess;
    };
    renderSite();
    siteToggle.addEventListener("click", async () => {
      if (!usable || tab?.id === void 0) return;
      const turningOn = siteToggle.getAttribute("aria-checked") !== "true";
      if (turningOn && !hasAccess) {
        const granted = await chrome.permissions.request({ origins: [pattern] });
        if (!granted) return;
        hasAccess = true;
        await setSiteEnabled(host, true);
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["detector.js"] }).catch(() => {
        });
      } else {
        await setSiteEnabled(host, turningOn);
      }
      settings = await loadSettings();
      renderSite();
    });
    runOnce.addEventListener("click", async () => {
      if (tab?.id === void 0) return;
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ENHANCER_FILES }).catch(() => {
      });
      window.close();
    });
    const swatches = $("swatches");
    for (const c of PALETTE) {
      const b = document.createElement("button");
      b.className = "swatch";
      b.dataset.color = c;
      b.setAttribute("aria-label", `Highlight colour ${c}`);
      b.style.setProperty("--c", c);
      b.addEventListener("click", () => void saveSettings({ highlightColor: c }));
      swatches.append(b);
    }
    const custom = $("custom-color");
    custom.addEventListener("change", () => void saveSettings({ highlightColor: custom.value }));
    document.querySelectorAll(".seg").forEach((seg) => {
      seg.addEventListener("click", (e) => {
        const b = e.target.closest("button[data-val]");
        if (b) void saveSettings({ [seg.dataset.key]: b.dataset.val });
      });
    });
    const hlToggle = $("highlight-toggle");
    hlToggle.addEventListener("click", () => void saveSettings({ highlight: !settings.highlight }));
    const flow = $("flow-toggle");
    flow.addEventListener("click", () => void saveSettings({ flowAnimation: !settings.flowAnimation }));
    const theme = $("theme");
    for (const [value, label] of Object.entries(THEME_LABELS)) theme.add(new Option(label, value));
    theme.addEventListener("change", () => void saveSettings({ theme: theme.value }));
    const renderPrefs = () => {
      document.querySelectorAll(".seg").forEach((seg) => {
        const current = String(settings[seg.dataset.key]);
        seg.querySelectorAll("button").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.val === current)));
      });
      hlToggle.setAttribute("aria-checked", String(settings.highlight));
      document.querySelectorAll(".seg").forEach((seg) => seg.classList.toggle("disabled", !settings.highlight));
      swatches.classList.toggle("disabled", !settings.highlight);
      let matched = false;
      swatches.querySelectorAll(".swatch").forEach((b) => {
        const on = b.dataset.color.toLowerCase() === settings.highlightColor.toLowerCase();
        matched ||= on;
        b.setAttribute("aria-checked", String(on));
      });
      const customLabel = custom.parentElement;
      customLabel.setAttribute("aria-checked", String(!matched));
      customLabel.style.setProperty("--c", settings.highlightColor);
      if (/^#[0-9a-f]{6}$/i.test(settings.highlightColor)) custom.value = settings.highlightColor;
      flow.setAttribute("aria-checked", String(settings.flowAnimation));
      theme.value = settings.theme;
    };
    renderPrefs();
    watchSettings((s) => {
      settings = s;
      renderPrefs();
      renderSite();
    });
  }
  void main();
})();
