"use strict";
(() => {
  // src/shared/settings.ts
  var DEFAULT_SETTINGS = {
    highlight: true,
    highlightMode: "neighbors",
    direction: "both",
    highlightColor: "#f59e0b",
    flowAnimation: false,
    flowDuration: 1.5,
    buildDuration: 8,
    theme: "auto",
    disabledSites: []
  };
  var TIMING = {
    flowDuration: { min: 0.2, max: 3, step: 0.1 },
    buildDuration: { min: 1, max: 10, step: 0.2 }
  };
  var PALETTE = ["#f59e0b", "#ef4444", "#ec4899", "#a855f7", "#6366f1", "#0ea5e9", "#14b8a6", "#22c55e"];
  var KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.sync.get(KEYS);
    const merged = { ...DEFAULT_SETTINGS, ...stored };
    if (merged.highlightMode === "off") {
      merged.highlight = typeof stored.highlight === "boolean" ? stored.highlight : false;
      merged.highlightMode = DEFAULT_SETTINGS.highlightMode;
    }
    return merged;
  }
  function saveSettings(patch) {
    return chrome.storage.sync.set(patch);
  }
  function watchSettings(cb) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !KEYS.some((k) => k in changes)) return;
      loadSettings().then(cb);
    });
  }
  function isSiteEnabled(s, host) {
    return !s.disabledSites.includes(host);
  }
  async function setSiteEnabled(host, enabled) {
    const { disabledSites } = await loadSettings();
    const next = disabledSites.filter((h) => h !== host);
    if (!enabled) next.push(host);
    await saveSettings({ disabledSites: next });
  }
  var MERMAID_SOURCE_SELECTOR = [
    'pre[lang="mermaid"]',
    'pre[data-language="mermaid"]',
    "pre.mermaid",
    "code.language-mermaid",
    "div.language-mermaid pre",
    "div.mermaid:not([data-processed])"
  ].join(",");
  var MERMAID_SVG_SELECTOR = [
    'svg[id*="mermaid" i][aria-roledescription]',
    '[class*="mermaid" i] svg[aria-roledescription]'
  ].join(",");
  var DIAGRAM_HINT_SELECTOR = [
    'section[data-type="mermaid"]',
    MERMAID_SOURCE_SELECTOR,
    MERMAID_SVG_SELECTOR
  ].join(",");

  // src/enhancer/sources.ts
  var HOST_TAG = "mermaid-lens-viewer";
  function insideManaged(el, managed) {
    for (let cur = el; cur; cur = cur.parentElement) {
      if (managed.has(cur) || cur.localName === HOST_TAG) return true;
    }
    return false;
  }
  function githubSource(section) {
    const target = section.querySelector(".js-render-enrichment-target");
    if (target?.dataset.plain) return target.dataset.plain;
    try {
      const data = JSON.parse(target?.dataset.json ?? "").data;
      if (typeof data === "string") return data;
    } catch {
    }
    return section.querySelector("pre")?.textContent ?? void 0;
  }
  function codeText(el) {
    const code = el.querySelector("code") ?? el;
    const lines = [...code.querySelectorAll(":scope > .line, :scope > .ec-line > .code")];
    if (!lines.length) return code.textContent ?? "";
    return lines.map((line) => line.textContent?.replace(/\r?\n$/, "") ?? "").join("\n");
  }
  function findDiagrams(managed) {
    const found = [];
    const claim = (s) => {
      if (insideManaged(s.anchor, managed)) return;
      if (s.code !== void 0 && !s.code.trim()) return;
      managed.add(s.anchor);
      found.push(s);
    };
    for (const section of document.querySelectorAll('section[data-type="mermaid"]')) {
      const code = githubSource(section);
      if (code !== void 0) claim({ anchor: section, code });
    }
    for (const el of document.querySelectorAll(MERMAID_SOURCE_SELECTOR)) {
      if (el.closest('section[data-type="mermaid"]') || el.querySelector("svg")) continue;
      if (el.isContentEditable || el.closest("textarea")) continue;
      const pre = el.closest("pre");
      const anchor = pre?.closest("div.language-mermaid") ?? pre ?? el;
      claim({ anchor, code: codeText(el) });
    }
    for (const svg2 of document.querySelectorAll(MERMAID_SVG_SELECTOR)) {
      if (svg2.closest('section[data-type="mermaid"]')) continue;
      claim({ anchor: svg2, svg: svg2 });
    }
    return found;
  }

  // src/enhancer/animate.ts
  var BASE_BUILD_SECONDS = 3.2;
  var BuildAnimation = class {
    constructor(svg2) {
      this.svg = svg2;
    }
    svg;
    running = [];
    timers = [];
    restore = [];
    scale = 1;
    get playing() {
      return this.running.some((a) => a.playState === "running");
    }
    stop() {
      this.running.forEach((a) => a.cancel());
      this.timers.forEach((t) => clearTimeout(t));
      this.restore.forEach((r) => r());
      this.running = [];
      this.timers = [];
      this.restore = [];
    }
    /** `scale` stretches or shrinks every delay and duration (1 ≈ BASE_BUILD_SECONDS). */
    play(graph, onDone, scale = 1) {
      this.stop();
      this.scale = scale;
      const total = graph ? this.playGraph(graph) : this.playGeneric();
      this.timers.push(window.setTimeout(() => {
        this.stop();
        onDone?.();
      }, total + 50));
    }
    fade(el, delay, duration) {
      this.running.push(
        el.animate([{ opacity: 0 }, { opacity: 1 }], { delay, duration, easing: "ease-out", fill: "backwards" })
      );
    }
    playGraph(graph) {
      const level = levels(graph);
      const maxLevel = Math.max(0, ...level.values());
      const step = Math.min(520, Math.max(160, 3200 / (maxLevel + 1))) * this.scale;
      for (const n of graph.nodes) {
        if (n.cluster) this.fade(n.el, 0, step * 2);
        else this.fade(n.el, (level.get(n) ?? 0) * step, step * 0.9);
      }
      for (const e of graph.edges) {
        const start = ((e.from && level.get(e.from)) ?? 0) * step + step * 0.6;
        const len = safeLength(e.el);
        const duration = step * 0.9;
        const markers = ["marker-start", "marker-end"].map((a) => [a, e.el.getAttribute(a)]);
        markers.forEach(([a, v]) => v && e.el.removeAttribute(a));
        const putBack = () => markers.forEach(([a, v]) => v && e.el.setAttribute(a, v));
        this.restore.push(putBack);
        this.timers.push(window.setTimeout(putBack, start + duration));
        if (len > 0) {
          this.running.push(
            e.el.animate(
              [
                { strokeDasharray: `${len} ${len}`, strokeDashoffset: len },
                { strokeDasharray: `${len} ${len}`, strokeDashoffset: 0 }
              ],
              { delay: start, duration, easing: "ease-in-out", fill: "backwards" }
            )
          );
        } else {
          this.fade(e.el, start, duration);
        }
        for (const l of e.labels) this.fade(l, start + duration * 0.5, duration * 0.6);
      }
      return (maxLevel + 1) * step + step;
    }
    playGeneric() {
      const root = this.svg.querySelector(":scope > g") ?? this.svg;
      let items = [...this.svg.children].filter((c) => !c.matches("style, defs, title, desc, .ml-hit"));
      if (items.length === 1 && root.children.length > 1) items = [...root.children];
      items = items.slice(0, 400);
      const step = Math.min(220, Math.max(12, 2600 / Math.max(1, items.length))) * this.scale;
      const duration = Math.max(180 * this.scale, step * 2);
      items.forEach((el, i) => this.fade(el, i * step, duration));
      return items.length * step + duration;
    }
  };
  function safeLength(p) {
    try {
      return p.getTotalLength();
    } catch {
      return 0;
    }
  }
  function levels(graph) {
    const level = /* @__PURE__ */ new Map();
    const real = graph.nodes.filter((n) => !n.cluster);
    const visit = (roots) => {
      const queue = [...roots];
      roots.forEach((r) => level.set(r, level.get(r) ?? 0));
      while (queue.length) {
        const n = queue.shift();
        for (const e of n.out) {
          if (e.to && !level.has(e.to)) {
            level.set(e.to, level.get(n) + 1);
            queue.push(e.to);
          }
        }
      }
    };
    visit(real.filter((n) => n.in.every((e) => !e.from || e.from === n)));
    for (const n of real) if (!level.has(n)) visit([n]);
    return level;
  }

  // src/enhancer/export.ts
  function serializeSvg({ svg: svg2, styleText, natural }) {
    const clone2 = svg2.cloneNode(true);
    clone2.querySelectorAll('.ml-hit, marker[id$="--ml-hl"]').forEach((n) => n.remove());
    clone2.querySelectorAll("[data-ml-marker-start], [data-ml-marker-end], [data-ml-marker-mid]").forEach((el) => {
      for (const a of ["marker-start", "marker-end", "marker-mid"]) {
        const v = el.getAttribute(`data-ml-${a}`);
        if (v !== null) {
          el.setAttribute(a, v);
          el.removeAttribute(`data-ml-${a}`);
        }
      }
    });
    const strip = (el) => {
      const cls = el.getAttribute("class");
      if (cls && /\bml-/.test(cls)) {
        const next = cls.split(/\s+/).filter((c) => !c.startsWith("ml-")).join(" ");
        if (next) el.setAttribute("class", next);
        else el.removeAttribute("class");
      }
    };
    strip(clone2);
    clone2.querySelectorAll("[class]").forEach(strip);
    clone2.querySelectorAll("[style]").forEach((el) => {
      const s = el.style;
      s.removeProperty("opacity");
      s.removeProperty("stroke-dasharray");
      s.removeProperty("stroke-dashoffset");
    });
    clone2.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    clone2.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
    clone2.setAttribute("viewBox", `${natural.x} ${natural.y} ${natural.w} ${natural.h}`);
    clone2.setAttribute("width", String(Math.ceil(natural.w)));
    clone2.setAttribute("height", String(Math.ceil(natural.h)));
    clone2.removeAttribute("style");
    clone2.removeAttribute("preserveAspectRatio");
    if (styleText) {
      const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
      style.textContent = styleText;
      clone2.prepend(style);
    }
    return new XMLSerializer().serializeToString(clone2);
  }
  async function svgToPng(src, scale = 2) {
    const markup = serializeSvg(src);
    const img = new Image();
    img.decoding = "async";
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(markup);
    await img.decode();
    const w = Math.ceil(src.natural.w * scale);
    const h = Math.ceil(src.natural.h * scale);
    const pad = 16 * scale;
    const canvas = document.createElement("canvas");
    canvas.width = w + pad * 2;
    canvas.height = h + pad * 2;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = src.background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, pad, pad, w, h);
    return new Promise(
      (resolve, reject) => canvas.toBlob((b) => b ? resolve(b) : reject(new Error("PNG encoding failed")), "image/png")
    );
  }
  async function copyText(text2) {
    try {
      await navigator.clipboard.writeText(text2);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text2;
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
      document.body.append(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      if (!ok) throw new Error("Clipboard unavailable");
    }
  }
  function copyPng(png) {
    return navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
  }
  function download(filename, data, type = "image/svg+xml") {
    const blob = typeof data === "string" ? new Blob([data], { type }) : data;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.style.display = "none";
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
  function mermaidLiveUrl(code, theme) {
    const state = JSON.stringify({ code, mermaid: JSON.stringify({ theme }), autoSync: true, updateDiagram: true });
    const bytes = new TextEncoder().encode(state);
    let bin = "";
    bytes.forEach((b) => bin += String.fromCharCode(b));
    return "https://mermaid.live/edit#base64:" + btoa(bin);
  }

  // src/enhancer/graph.ts
  var EDGE_SELECTOR = [
    'path[data-edge="true"]',
    "path.flowchart-link",
    ".edgePaths path",
    ".edgePath path",
    "path.transition",
    "path.relation",
    "path.relationshipLine"
  ].join(",");
  function matrixToRoot(el, svg2) {
    let m = new DOMMatrix();
    let cur = el;
    while (cur && cur !== svg2) {
      const t = cur.transform?.baseVal?.consolidate();
      if (t) m = DOMMatrix.fromMatrix(t.matrix).multiply(m);
      cur = cur.parentElement;
    }
    return m;
  }
  function pointAt(path, at, m) {
    const p = path.getPointAtLength(at);
    return new DOMPoint(p.x, p.y).matrixTransform(m);
  }
  function rootBox(el, svg2) {
    let b;
    try {
      b = el.getBBox();
    } catch {
      return null;
    }
    if (!b.width && !b.height) return null;
    const m = matrixToRoot(el, svg2);
    const pts = [
      new DOMPoint(b.x, b.y),
      new DOMPoint(b.x + b.width, b.y),
      new DOMPoint(b.x, b.y + b.height),
      new DOMPoint(b.x + b.width, b.y + b.height)
    ].map((p) => p.matrixTransform(m));
    return {
      x1: Math.min(...pts.map((p) => p.x)),
      y1: Math.min(...pts.map((p) => p.y)),
      x2: Math.max(...pts.map((p) => p.x)),
      y2: Math.max(...pts.map((p) => p.y))
    };
  }
  function outsideDist(b, x, y) {
    const dx = Math.max(b.x1 - x, 0, x - b.x2);
    const dy = Math.max(b.y1 - y, 0, y - b.y2);
    return Math.hypot(dx, dy);
  }
  function borderDist(b, x, y) {
    const out = outsideDist(b, x, y);
    if (out > 0) return out;
    return Math.min(x - b.x1, b.x2 - x, y - b.y1, b.y2 - y);
  }
  function semanticId(el, svgId) {
    let id = el.id || "";
    if (svgId && id.startsWith(svgId + "-")) id = id.slice(svgId.length + 1);
    const m = id.match(/^(?:flowchart|state|classId|entity)-(.+)-\d+$/);
    return m ? m[1] : id;
  }
  function extractGraph(svg2) {
    const svgId = svg2.id;
    const nodeEls = [...svg2.querySelectorAll("g.node")].filter((n) => !n.closest("defs, marker"));
    if (nodeEls.length === 0) return null;
    const clusterEls = [...svg2.querySelectorAll("g.cluster")];
    const nodes = [];
    const byId = /* @__PURE__ */ new Map();
    const byElement = /* @__PURE__ */ new Map();
    for (const [el, cluster] of [
      ...nodeEls.map((e) => [e, false]),
      ...clusterEls.map((e) => [e, true])
    ]) {
      const box = rootBox(el, svg2);
      if (!box) continue;
      const node = { kind: "node", id: semanticId(el, svgId), el, cluster, box, out: [], in: [] };
      nodes.push(node);
      byId.set(node.id, node);
      byElement.set(el, node);
    }
    const nearest = (x, y) => {
      let best;
      let bestD = Infinity;
      for (const n of nodes) {
        const d = (n.cluster ? borderDist(n.box, x, y) : outsideDist(n.box, x, y)) + (n.cluster ? 0.5 : 0);
        if (d < bestD) {
          bestD = d;
          best = n;
        }
      }
      return bestD <= 40 ? best : void 0;
    };
    const semanticEnds = (edgeId) => {
      const m = edgeId.match(/^L_(.+)_\d+$/);
      if (!m) return null;
      const parts = m[1].split("_");
      let found = null;
      for (let i = 1; i < parts.length; i++) {
        const a = byId.get(parts.slice(0, i).join("_"));
        const b = byId.get(parts.slice(i).join("_"));
        if (a && b) {
          if (found) return null;
          found = [a, b];
        }
      }
      return found;
    };
    const seen = /* @__PURE__ */ new Set();
    const edges = [];
    for (const el of svg2.querySelectorAll(EDGE_SELECTOR)) {
      if (seen.has(el) || el.closest("defs, marker, g.node") || el.classList.contains("ml-hit")) continue;
      seen.add(el);
      const edge = { kind: "edge", el, labels: [] };
      const dataId = el.getAttribute("data-id") || el.id.replace(svgId + "-", "");
      const sem = semanticEnds(dataId);
      if (sem) {
        [edge.from, edge.to] = sem;
      } else {
        try {
          const len = el.getTotalLength();
          const m = matrixToRoot(el, svg2);
          const p0 = pointAt(el, 0, m);
          const p1 = pointAt(el, len, m);
          edge.from = nearest(p0.x, p0.y);
          edge.to = nearest(p1.x, p1.y);
        } catch {
        }
      }
      edge.from?.out.push(edge);
      edge.to?.in.push(edge);
      el.classList.add("ml-edge");
      byElement.set(el, edge);
      edges.push(edge);
    }
    attachLabels(svg2, edges, byElement);
    addHitAreas(edges, byElement);
    return { nodes, edges, byElement };
  }
  function attachLabels(svg2, edges, byElement) {
    const byDataId = /* @__PURE__ */ new Map();
    for (const e of edges) {
      const id = e.el.getAttribute("data-id");
      if (id) byDataId.set(id, e);
    }
    const mids = edges.map((e) => {
      try {
        const p = pointAt(e.el, e.el.getTotalLength() / 2, matrixToRoot(e.el, svg2));
        return { e, x: p.x, y: p.y };
      } catch {
        return null;
      }
    });
    for (const label of svg2.querySelectorAll("g.edgeLabel")) {
      let edge = byDataId.get(label.querySelector("[data-id]")?.getAttribute("data-id") ?? "");
      if (!edge) {
        const box = rootBox(label, svg2);
        if (!box) continue;
        const cx = (box.x1 + box.x2) / 2;
        const cy = (box.y1 + box.y2) / 2;
        let bestD = 60;
        for (const m of mids) {
          if (!m) continue;
          const d = Math.hypot(m.x - cx, m.y - cy);
          if (d < bestD) {
            bestD = d;
            edge = m.e;
          }
        }
      }
      if (!edge) continue;
      edge.labels.push(label);
      label.classList.add("ml-elabel");
      byElement.set(label, edge);
    }
  }
  function addHitAreas(edges, byElement) {
    for (const e of edges) {
      const hit = document.createElementNS("http://www.w3.org/2000/svg", e.el.localName);
      for (const name of ["d", "x1", "y1", "x2", "y2", "transform"]) {
        const value = e.el.getAttribute(name);
        if (value !== null) hit.setAttribute(name, value);
      }
      hit.setAttribute("class", "ml-hit");
      e.el.after(hit);
      byElement.set(hit, e);
    }
  }
  function expand(sel, mode, direction) {
    const nodes = /* @__PURE__ */ new Set();
    const edges = /* @__PURE__ */ new Set();
    const down = direction !== "up";
    const up = direction !== "down";
    const walk = (start, dir) => {
      const queue = [start];
      const visited = /* @__PURE__ */ new Set([start]);
      while (queue.length) {
        const n = queue.shift();
        for (const e of n[dir]) {
          edges.add(e);
          const next = dir === "out" ? e.to : e.from;
          if (!next) continue;
          nodes.add(next);
          if (mode === "flow" && !visited.has(next)) {
            visited.add(next);
            queue.push(next);
          }
        }
      }
    };
    for (const n of sel.nodes) {
      nodes.add(n);
      if (down) walk(n, "out");
      if (up) walk(n, "in");
    }
    for (const e of sel.edges) {
      edges.add(e);
      if (e.from) nodes.add(e.from);
      if (e.to) nodes.add(e.to);
      if (mode === "flow") {
        if (down && e.to) walk(e.to, "out");
        if (up && e.from) walk(e.from, "in");
      }
    }
    return { nodes, edges };
  }

  // src/enhancer/highlight.ts
  var Highlighter = class {
    constructor(svg2, graph, enabled, mode, direction) {
      this.svg = svg2;
      this.graph = graph;
      this.enabled = enabled;
      this.mode = mode;
      this.direction = direction;
    }
    svg;
    graph;
    enabled;
    mode;
    direction;
    /** Clicked items; they stay lit until cleared and take precedence over hover. */
    pinned = { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() };
    hovered = null;
    lit = { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() };
    markerClones = /* @__PURE__ */ new Map();
    /** Whether anything is pinned (Esc clears pins before doing anything else). */
    get active() {
      return this.pinned.nodes.size + this.pinned.edges.size > 0;
    }
    configure(enabled, mode, direction) {
      if (enabled === this.enabled && mode === this.mode && direction === this.direction) return;
      this.enabled = enabled;
      this.mode = mode;
      this.direction = direction;
      if (!enabled) {
        this.pinned = { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() };
        this.hovered = null;
      }
      this.apply();
    }
    /** Preview the highlight for whatever the pointer is over (`null` when it leaves). */
    hover(item) {
      if (item === this.hovered) return;
      this.hovered = item;
      if (!this.active) this.apply();
    }
    /** Pin a node or edge; `additive` (shift-click) toggles it within the pinned set. */
    select(item, additive) {
      const set = item.kind === "node" ? this.pinned.nodes : this.pinned.edges;
      const soleSelection = set.has(item) && this.pinned.nodes.size + this.pinned.edges.size === 1;
      if (additive) {
        if (set.has(item)) set.delete(item);
        else set.add(item);
      } else {
        this.pinned.nodes.clear();
        this.pinned.edges.clear();
        if (!soleSelection) set.add(item);
      }
      this.apply();
    }
    /** Drop all pins (hover highlighting carries on). */
    clear() {
      this.pinned = { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() };
      this.apply();
    }
    current() {
      if (!this.enabled) return { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() };
      if (this.active) return this.pinned;
      const h = this.hovered;
      return {
        nodes: new Set(h?.kind === "node" ? [h] : []),
        edges: new Set(h?.kind === "edge" ? [h] : [])
      };
    }
    apply() {
      const sel = this.current();
      const next = sel.nodes.size + sel.edges.size === 0 ? { nodes: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Set() } : (this.graph.expand ?? expand)(sel, this.mode, this.direction);
      for (const n of this.graph.nodes) {
        n.el.classList.toggle("ml-on", next.nodes.has(n));
        n.el.classList.toggle("ml-sel", sel.nodes.has(n));
        for (const el of n.parts ?? []) {
          el.classList.toggle("ml-on", next.nodes.has(n));
          el.classList.toggle("ml-sel", sel.nodes.has(n));
        }
      }
      for (const e of this.graph.edges) {
        const on = next.edges.has(e);
        if (on !== this.lit.edges.has(e)) this.swapMarkers(e.el, on);
        e.el.classList.toggle("ml-on", on);
        e.el.classList.toggle("ml-sel", sel.edges.has(e));
        for (const l of e.labels) l.classList.toggle("ml-on", on);
      }
      this.lit = next;
      this.svg.classList.toggle("ml-has-hl", next.nodes.size + next.edges.size > 0);
    }
    /** Arrowheads are shared <marker>s; point lit edges at recoloured copies. */
    swapMarkers(path, on) {
      for (const attr of ["marker-start", "marker-end", "marker-mid"]) {
        if (on) {
          const v = path.getAttribute(attr);
          const id = v?.match(/url\(["']?#([^"')]+)["']?\)/)?.[1];
          if (!id) continue;
          const clone2 = this.markerClone(id, path);
          if (!clone2) continue;
          path.setAttribute(`data-ml-${attr}`, v);
          path.setAttribute(attr, `url(#${clone2})`);
        } else {
          const orig = path.getAttribute(`data-ml-${attr}`);
          if (orig === null) continue;
          path.setAttribute(attr, orig);
          path.removeAttribute(`data-ml-${attr}`);
        }
      }
    }
    markerClone(id, path) {
      const cached = this.markerClones.get(id);
      if (cached) return cached;
      const marker = [...this.svg.querySelectorAll("marker")].find((m) => m.id === id);
      if (!marker) return null;
      const clone2 = marker.cloneNode(true);
      clone2.id = `${id}--ml-hl`;
      marker.after(clone2);
      const lineColour = getComputedStyle(path).stroke;
      const originals = [marker, ...marker.querySelectorAll("*")];
      [clone2, ...clone2.querySelectorAll("*")].forEach((el, i) => {
        const cs = getComputedStyle(originals[i]);
        const s = el.style;
        if (cs.stroke && cs.stroke !== "none") s.setProperty("stroke", "var(--ml-hl)", "important");
        if (cs.fill && cs.fill !== "none" && (cs.fill === lineColour || cs.fill === cs.stroke))
          s.setProperty("fill", "var(--ml-hl)", "important");
      });
      this.markerClones.set(id, clone2.id);
      return clone2.id;
    }
  };

  // src/enhancer/icons.ts
  var paths = {
    highlight: '<circle cx="6" cy="6" r="2.6"/><circle cx="18" cy="6" r="2.6"/><circle cx="12" cy="18" r="2.6"/><path d="M8.6 6h6.8M7.3 8.3l3.4 7.3M16.7 8.3l-3.4 7.3"/>',
    flow: '<circle cx="5.5" cy="5.5" r="2.4"/><circle cx="12" cy="12" r="2.4"/><circle cx="18.5" cy="18.5" r="2.4"/><path d="M7.3 7.3l2.9 2.9M13.8 13.8l2.9 2.9"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 7.5V12l3 2"/>',
    play: '<path d="M8 5.6v12.8a.6.6 0 0 0 .9.5l10.2-6.4a.6.6 0 0 0 0-1L8.9 5.1a.6.6 0 0 0-.9.5z"/>',
    copy: '<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.2"/><path d="M15.5 8.5V6.2A2.2 2.2 0 0 0 13.3 4H6.2A2.2 2.2 0 0 0 4 6.2v7.1a2.2 2.2 0 0 0 2.2 2.2h2.3"/>',
    expand: '<path d="M4 9V5.2C4 4.5 4.5 4 5.2 4H9M15 4h3.8c.7 0 1.2.5 1.2 1.2V9M20 15v3.8c0 .7-.5 1.2-1.2 1.2H15M9 20H5.2C4.5 20 4 19.5 4 18.8V15"/>',
    collapse: '<path d="M9 4v3.8C9 8.5 8.5 9 7.8 9H4M20 9h-3.8C15.5 9 15 8.5 15 7.8V4M15 20v-3.8c0-.7.5-1.2 1.2-1.2H20M4 15h3.8c.7 0 1.2.5 1.2 1.2V20"/>',
    more: '<circle cx="5.5" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="18.5" cy="12" r="1.3" fill="currentColor"/>',
    plus: '<path d="M12 5.5v13M5.5 12h13"/>',
    minus: '<path d="M5.5 12h13"/>',
    fit: '<path d="M4 8.5V4h4.5M20 8.5V4h-4.5M4 15.5V20h4.5M20 15.5V20h-4.5"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.4"/>',
    code: '<path d="M8.5 7.5 4 12l4.5 4.5M15.5 7.5 20 12l-4.5 4.5M13.4 5.5l-2.8 13"/>',
    image: '<rect x="4" y="4" width="16" height="16" rx="2.4"/><circle cx="9.2" cy="9.2" r="1.6"/><path d="m20 15.2-4.3-4.3a1.2 1.2 0 0 0-1.7 0L6.5 18.4"/>',
    vector: '<path d="M5 19 12 5l7 14"/><circle cx="12" cy="5" r="1.8"/><circle cx="5" cy="19" r="1.8"/><circle cx="19" cy="19" r="1.8"/><path d="M7.5 14.5h9"/>',
    download: '<path d="M12 4.5v10.5M7.5 10.8 12 15.3l4.5-4.5M5 19.5h14"/>',
    external: '<path d="M14 4h6v6M20 4l-8.5 8.5M18 14v4.8c0 .7-.5 1.2-1.2 1.2H5.2C4.5 20 4 19.5 4 18.8V7.2C4 6.5 4.5 6 5.2 6H10"/>',
    power: '<path d="M12 4v7.5M7.2 6.9a7 7 0 1 0 9.6 0"/>',
    replay: '<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3L4.5 8.9"/><path d="M4.5 4.5v4.4h4.4"/>',
    reset: '<path d="M4 12h3M17 12h3M12 4v3M12 17v3"/><circle cx="12" cy="12" r="5"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    waves: '<path d="M3.5 9c2.1-2 4.2-2 6.3 0s4.2 2 6.3 0 3.2-1.4 4.4-.9M3.5 15c2.1-2 4.2-2 6.3 0s4.2 2 6.3 0 3.2-1.4 4.4-.9"/>'
  };
  function icon(name) {
    return `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]}</svg>`;
  }

  // ../../node_modules/dompurify/dist/purify.es.mjs
  function _OverloadYield(e, d) {
    this.v = e, this.k = d;
  }
  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
  }
  function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
      var e, n, i, u, a = [], f = true, o = false;
      try {
        if (i = (t = t.call(r)).next, 0 === l) {
          if (Object(t) !== t) return;
          f = false;
        } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = true) ;
      } catch (r2) {
        o = true, n = r2;
      } finally {
        try {
          if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
        } finally {
          if (o) throw n;
        }
      }
      return a;
    }
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }
  function AsyncGenerator(e) {
    var t, n;
    function resume(t2, n2) {
      try {
        var r = e[t2](n2), o = r.value, u = o instanceof _OverloadYield;
        Promise.resolve(u ? o.v : o).then(function(n3) {
          if (u) {
            var i = "return" === t2 && o.k ? t2 : "next";
            if (!o.k || n3.done) return resume(i, n3);
            n3 = e[i](n3).value;
          }
          settle(!!r.done, n3);
        }, function(e2) {
          resume("throw", e2);
        });
      } catch (e2) {
        settle(2, e2);
      }
    }
    function settle(e2, r) {
      2 === e2 ? t.reject(r) : t.resolve({
        value: r,
        done: e2
      }), (t = t.next) ? resume(t.key, t.arg) : n = null;
    }
    this._invoke = function(e2, r) {
      return new Promise(function(o, u) {
        var i = {
          key: e2,
          arg: r,
          resolve: o,
          reject: u,
          next: null
        };
        n ? n = n.next = i : (t = n = i, resume(e2, r));
      });
    }, "function" != typeof e.return && (this.return = void 0);
  }
  AsyncGenerator.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function() {
    return this;
  }, AsyncGenerator.prototype.next = function(e) {
    return this._invoke("next", e);
  }, AsyncGenerator.prototype.throw = function(e) {
    return this._invoke("throw", e);
  }, AsyncGenerator.prototype.return = function(e) {
    return this._invoke("return", e);
  };
  var entries = Object.entries;
  var setPrototypeOf = Object.setPrototypeOf;
  var isFrozen = Object.isFrozen;
  var getPrototypeOf = Object.getPrototypeOf;
  var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  var freeze = Object.freeze;
  var seal = Object.seal;
  var create = Object.create;
  var _ref = typeof Reflect !== "undefined" && Reflect;
  var apply = _ref.apply;
  var construct = _ref.construct;
  if (!freeze) freeze = function freeze2(x) {
    return x;
  };
  if (!seal) seal = function seal2(x) {
    return x;
  };
  if (!apply) apply = function apply2(func, thisArg) {
    for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
    return func.apply(thisArg, args);
  };
  if (!construct) construct = function construct2(Func) {
    for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
    return new Func(...args);
  };
  var arrayForEach = unapply(Array.prototype.forEach);
  Array.prototype.indexOf;
  var arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
  var arrayPop = unapply(Array.prototype.pop);
  var arrayPush = unapply(Array.prototype.push);
  var arraySlice = unapply(Array.prototype.slice);
  var arraySplice = unapply(Array.prototype.splice);
  var arrayIsArray = Array.isArray;
  var setCreate = unconstruct(Set);
  var setAdd = unapply(Set.prototype.add);
  var setHas = unapply(Set.prototype.has);
  var stringToLowerCase = unapply(String.prototype.toLowerCase);
  var stringToString = unapply(String.prototype.toString);
  var stringMatch = unapply(String.prototype.match);
  var stringReplace = unapply(String.prototype.replace);
  var stringIndexOf = unapply(String.prototype.indexOf);
  var stringTrim = unapply(String.prototype.trim);
  var numberToString = unapply(Number.prototype.toString);
  var booleanToString = unapply(Boolean.prototype.toString);
  var bigintToString = typeof BigInt === "undefined" ? null : unapply(BigInt.prototype.toString);
  var symbolToString = typeof Symbol === "undefined" ? null : unapply(Symbol.prototype.toString);
  var objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
  var objectToString = unapply(Object.prototype.toString);
  var regExpTest = unapply(RegExp.prototype.test);
  var typeErrorCreate = unconstruct(TypeError);
  function unapply(func) {
    return function(thisArg) {
      if (thisArg instanceof RegExp) thisArg.lastIndex = 0;
      for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) args[_key3 - 1] = arguments[_key3];
      return apply(func, thisArg, args);
    };
  }
  function unconstruct(Func) {
    return function() {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) args[_key4] = arguments[_key4];
      return construct(Func, args);
    };
  }
  function addToSet(set, array) {
    let transformCaseFunc = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : stringToLowerCase;
    if (setPrototypeOf) setPrototypeOf(set, null);
    if (!arrayIsArray(array)) return set;
    let l = array.length;
    while (l--) {
      let element = array[l];
      if (typeof element === "string") {
        const lcElement = transformCaseFunc(element);
        if (lcElement !== element) {
          if (!isFrozen(array)) array[l] = lcElement;
          element = lcElement;
        }
      }
      set[element] = true;
    }
    return set;
  }
  function cleanArray(array) {
    for (let index = 0; index < array.length; index++) if (!objectHasOwnProperty(array, index)) array[index] = null;
    return array;
  }
  function clone(object) {
    const newObject = create(null);
    for (const _ref2 of entries(object)) {
      var _ref3 = _slicedToArray(_ref2, 2);
      const property = _ref3[0];
      const value = _ref3[1];
      if (objectHasOwnProperty(object, property)) {
        if (arrayIsArray(value)) newObject[property] = cleanArray(value);
        else if (value && typeof value === "object" && value.constructor === Object) newObject[property] = clone(value);
        else newObject[property] = value;
      }
    }
    return newObject;
  }
  function stringifyValue(value) {
    switch (typeof value) {
      case "string":
        return value;
      case "number":
        return numberToString(value);
      case "boolean":
        return booleanToString(value);
      case "bigint":
        return bigintToString ? bigintToString(value) : "0";
      case "symbol":
        return symbolToString ? symbolToString(value) : "Symbol()";
      case "undefined":
        return objectToString(value);
      case "function":
      case "object": {
        if (value === null) return objectToString(value);
        const valueAsRecord = value;
        const valueToString = lookupGetter(valueAsRecord, "toString");
        if (typeof valueToString === "function") {
          const stringified = valueToString(valueAsRecord);
          return typeof stringified === "string" ? stringified : objectToString(stringified);
        }
        return objectToString(value);
      }
      default:
        return objectToString(value);
    }
  }
  function lookupGetter(object, prop) {
    while (object !== null) {
      const desc = getOwnPropertyDescriptor(object, prop);
      if (desc) {
        if (desc.get) return unapply(desc.get);
        if (typeof desc.value === "function") return unapply(desc.value);
      }
      object = getPrototypeOf(object);
    }
    function fallbackValue() {
      return null;
    }
    return fallbackValue;
  }
  function lookupAccessor(object, prop) {
    while (object !== null) {
      const desc = getOwnPropertyDescriptor(object, prop);
      if (desc) return desc.get ? unapply(desc.get) : null;
      object = getPrototypeOf(object);
    }
    return null;
  }
  function isRegex(value) {
    try {
      regExpTest(value, "");
      return true;
    } catch (_unused) {
      return false;
    }
  }
  var html$1 = freeze([
    "a",
    "abbr",
    "acronym",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "bdi",
    "bdo",
    "big",
    "blink",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "center",
    "cite",
    "code",
    "col",
    "colgroup",
    "content",
    "data",
    "datalist",
    "dd",
    "decorator",
    "del",
    "details",
    "dfn",
    "dialog",
    "dir",
    "div",
    "dl",
    "dt",
    "element",
    "em",
    "fieldset",
    "figcaption",
    "figure",
    "font",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "legend",
    "li",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "menuitem",
    "meter",
    "nav",
    "nobr",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "search",
    "section",
    "select",
    "shadow",
    "slot",
    "small",
    "source",
    "spacer",
    "span",
    "strike",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "track",
    "tt",
    "u",
    "ul",
    "var",
    "video",
    "wbr"
  ]);
  var svg$1 = freeze([
    "svg",
    "a",
    "altglyph",
    "altglyphdef",
    "altglyphitem",
    "animatecolor",
    "animatemotion",
    "animatetransform",
    "circle",
    "clippath",
    "defs",
    "desc",
    "ellipse",
    "enterkeyhint",
    "exportparts",
    "filter",
    "font",
    "g",
    "glyph",
    "glyphref",
    "hkern",
    "image",
    "inputmode",
    "line",
    "lineargradient",
    "marker",
    "mask",
    "metadata",
    "mpath",
    "part",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialgradient",
    "rect",
    "stop",
    "style",
    "switch",
    "symbol",
    "text",
    "textpath",
    "title",
    "tref",
    "tspan",
    "view",
    "vkern"
  ]);
  var svgFilters = freeze([
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feDropShadow",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence"
  ]);
  var svgDisallowed = freeze([
    "animate",
    "color-profile",
    "cursor",
    "discard",
    "font-face",
    "font-face-format",
    "font-face-name",
    "font-face-src",
    "font-face-uri",
    "foreignobject",
    "hatch",
    "hatchpath",
    "mesh",
    "meshgradient",
    "meshpatch",
    "meshrow",
    "missing-glyph",
    "script",
    "set",
    "solidcolor",
    "unknown",
    "use"
  ]);
  var mathMl$1 = freeze([
    "math",
    "menclose",
    "merror",
    "mfenced",
    "mfrac",
    "mglyph",
    "mi",
    "mlabeledtr",
    "mmultiscripts",
    "mn",
    "mo",
    "mover",
    "mpadded",
    "mphantom",
    "mroot",
    "mrow",
    "ms",
    "mspace",
    "msqrt",
    "mstyle",
    "msub",
    "msup",
    "msubsup",
    "mtable",
    "mtd",
    "mtext",
    "mtr",
    "munder",
    "munderover",
    "mprescripts"
  ]);
  var mathMlDisallowed = freeze([
    "maction",
    "maligngroup",
    "malignmark",
    "mlongdiv",
    "mscarries",
    "mscarry",
    "msgroup",
    "mstack",
    "msline",
    "msrow",
    "semantics",
    "annotation",
    "annotation-xml",
    "mprescripts",
    "none"
  ]);
  var text = freeze(["#text"]);
  var html = freeze([
    "accept",
    "action",
    "align",
    "alt",
    "autocapitalize",
    "autocomplete",
    "autopictureinpicture",
    "autoplay",
    "background",
    "bgcolor",
    "border",
    "capture",
    "cellpadding",
    "cellspacing",
    "checked",
    "cite",
    "class",
    "clear",
    "color",
    "cols",
    "colspan",
    "command",
    "commandfor",
    "controls",
    "controlslist",
    "coords",
    "crossorigin",
    "datetime",
    "decoding",
    "default",
    "dir",
    "disabled",
    "disablepictureinpicture",
    "disableremoteplayback",
    "download",
    "draggable",
    "enctype",
    "enterkeyhint",
    "exportparts",
    "face",
    "for",
    "headers",
    "height",
    "hidden",
    "high",
    "href",
    "hreflang",
    "id",
    "inert",
    "inputmode",
    "integrity",
    "ismap",
    "kind",
    "label",
    "lang",
    "list",
    "loading",
    "loop",
    "low",
    "max",
    "maxlength",
    "media",
    "method",
    "min",
    "minlength",
    "multiple",
    "muted",
    "name",
    "nonce",
    "noshade",
    "novalidate",
    "nowrap",
    "open",
    "optimum",
    "part",
    "pattern",
    "placeholder",
    "playsinline",
    "popover",
    "popovertarget",
    "popovertargetaction",
    "poster",
    "preload",
    "pubdate",
    "radiogroup",
    "readonly",
    "rel",
    "required",
    "rev",
    "reversed",
    "role",
    "rows",
    "rowspan",
    "spellcheck",
    "scope",
    "selected",
    "shape",
    "size",
    "sizes",
    "slot",
    "span",
    "srclang",
    "start",
    "src",
    "srcset",
    "step",
    "style",
    "summary",
    "tabindex",
    "title",
    "translate",
    "type",
    "usemap",
    "valign",
    "value",
    "width",
    "wrap",
    "xmlns"
  ]);
  var svg = freeze([
    "accent-height",
    "accumulate",
    "additive",
    "alignment-baseline",
    "amplitude",
    "ascent",
    "attributename",
    "attributetype",
    "azimuth",
    "basefrequency",
    "baseline-shift",
    "begin",
    "bias",
    "by",
    "class",
    "clip",
    "clippathunits",
    "clip-path",
    "clip-rule",
    "color",
    "color-interpolation",
    "color-interpolation-filters",
    "color-profile",
    "color-rendering",
    "cx",
    "cy",
    "d",
    "dx",
    "dy",
    "diffuseconstant",
    "direction",
    "display",
    "divisor",
    "dominant-baseline",
    "dur",
    "edgemode",
    "elevation",
    "end",
    "exponent",
    "fill",
    "fill-opacity",
    "fill-rule",
    "filter",
    "filterunits",
    "flood-color",
    "flood-opacity",
    "font-family",
    "font-size",
    "font-size-adjust",
    "font-stretch",
    "font-style",
    "font-variant",
    "font-weight",
    "fx",
    "fy",
    "g1",
    "g2",
    "glyph-name",
    "glyphref",
    "gradientunits",
    "gradienttransform",
    "height",
    "href",
    "id",
    "image-rendering",
    "in",
    "in2",
    "intercept",
    "k",
    "k1",
    "k2",
    "k3",
    "k4",
    "kerning",
    "keypoints",
    "keysplines",
    "keytimes",
    "lang",
    "lengthadjust",
    "letter-spacing",
    "kernelmatrix",
    "kernelunitlength",
    "lighting-color",
    "local",
    "marker-end",
    "marker-mid",
    "marker-start",
    "markerheight",
    "markerunits",
    "markerwidth",
    "maskcontentunits",
    "maskunits",
    "max",
    "mask",
    "mask-type",
    "media",
    "method",
    "mode",
    "min",
    "name",
    "numoctaves",
    "offset",
    "operator",
    "opacity",
    "order",
    "orient",
    "orientation",
    "origin",
    "overflow",
    "paint-order",
    "path",
    "pathlength",
    "patterncontentunits",
    "patterntransform",
    "patternunits",
    "pointer-events",
    "points",
    "preservealpha",
    "preserveaspectratio",
    "primitiveunits",
    "r",
    "rx",
    "ry",
    "radius",
    "refx",
    "refy",
    "repeatcount",
    "repeatdur",
    "restart",
    "result",
    "rotate",
    "scale",
    "seed",
    "shape-rendering",
    "slope",
    "specularconstant",
    "specularexponent",
    "spreadmethod",
    "startoffset",
    "stddeviation",
    "stitchtiles",
    "stop-color",
    "stop-opacity",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke",
    "stroke-width",
    "style",
    "surfacescale",
    "systemlanguage",
    "tabindex",
    "tablevalues",
    "targetx",
    "targety",
    "transform",
    "transform-origin",
    "text-anchor",
    "text-decoration",
    "text-orientation",
    "text-rendering",
    "textlength",
    "type",
    "u1",
    "u2",
    "unicode",
    "values",
    "vector-effect",
    "viewbox",
    "visibility",
    "version",
    "vert-adv-y",
    "vert-origin-x",
    "vert-origin-y",
    "width",
    "word-spacing",
    "wrap",
    "writing-mode",
    "xchannelselector",
    "ychannelselector",
    "x",
    "x1",
    "x2",
    "xmlns",
    "y",
    "y1",
    "y2",
    "z",
    "zoomandpan"
  ]);
  var mathMl = freeze([
    "accent",
    "accentunder",
    "align",
    "bevelled",
    "close",
    "columnalign",
    "columnlines",
    "columnspacing",
    "columnspan",
    "denomalign",
    "depth",
    "dir",
    "display",
    "displaystyle",
    "encoding",
    "fence",
    "frame",
    "height",
    "href",
    "id",
    "largeop",
    "length",
    "linethickness",
    "lquote",
    "lspace",
    "mathbackground",
    "mathcolor",
    "mathsize",
    "mathvariant",
    "maxsize",
    "minsize",
    "movablelimits",
    "notation",
    "numalign",
    "open",
    "rowalign",
    "rowlines",
    "rowspacing",
    "rowspan",
    "rspace",
    "rquote",
    "scriptlevel",
    "scriptminsize",
    "scriptsizemultiplier",
    "selection",
    "separator",
    "separators",
    "stretchy",
    "subscriptshift",
    "supscriptshift",
    "symmetric",
    "voffset",
    "width",
    "xmlns"
  ]);
  var xml = freeze([
    "xlink:href",
    "xml:id",
    "xlink:title",
    "xml:space",
    "xmlns:xlink"
  ]);
  var MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
  var ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
  var TMPLIT_EXPR = seal(/\${[\w\W]*/g);
  var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/);
  var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
  var IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i);
  var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
  var ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g);
  var DOCTYPE_NAME = seal(/^html$/i);
  var CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
  var ELEMENT_MARKUP_PROBE = seal(/<[/\w!]/g);
  var COMMENT_MARKUP_PROBE = seal(/<[/\w]/g);
  var FALLBACK_TAG_CLOSE = seal(/<\/no(script|embed|frames)/i);
  var SELF_CLOSING_TAG = seal(/\/>/i);
  var NODE_TYPE = {
    element: 1,
    attribute: 2,
    text: 3,
    cdataSection: 4,
    entityReference: 5,
    entityNode: 6,
    processingInstruction: 7,
    comment: 8,
    document: 9,
    documentType: 10,
    documentFragment: 11,
    notation: 12
  };
  var LITERAL_TEXT_ELEMENTS = freeze(addToSet({}, [
    "style",
    "script",
    "xmp",
    "iframe",
    "noembed",
    "noframes",
    "plaintext",
    "noscript"
  ]));
  var getGlobal = function getGlobal2() {
    return typeof window === "undefined" ? null : window;
  };
  var _createTrustedTypesPolicy = function _createTrustedTypesPolicy2(trustedTypes, purifyHostElement) {
    if (typeof trustedTypes !== "object" || typeof trustedTypes.createPolicy !== "function") return null;
    let suffix = null;
    const ATTR_NAME = "data-tt-policy-suffix";
    if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) suffix = purifyHostElement.getAttribute(ATTR_NAME);
    const policyName = "dompurify" + (suffix ? "#" + suffix : "");
    try {
      return trustedTypes.createPolicy(policyName, {
        createHTML(html2) {
          return html2;
        },
        createScriptURL(scriptUrl) {
          return scriptUrl;
        }
      });
    } catch (_) {
      console.warn("TrustedTypes policy " + policyName + " could not be created.");
      return null;
    }
  };
  var _createHooksMap = function _createHooksMap2() {
    return {
      afterSanitizeAttributes: [],
      afterSanitizeElements: [],
      afterSanitizeShadowDOM: [],
      beforeSanitizeAttributes: [],
      beforeSanitizeElements: [],
      beforeSanitizeShadowDOM: [],
      uponSanitizeAttribute: [],
      uponSanitizeElement: [],
      uponSanitizeShadowNode: []
    };
  };
  var _resolveSetOption = function _resolveSetOption2(cfg, key, fallback, options) {
    return objectHasOwnProperty(cfg, key) && arrayIsArray(cfg[key]) ? addToSet(options.base ? clone(options.base) : {}, cfg[key], options.transform) : fallback;
  };
  var _resolveObjectOption = function _resolveObjectOption2(cfg, key, makeFallback) {
    const value = objectHasOwnProperty(cfg, key) ? cfg[key] : void 0;
    return value && typeof value === "object" ? clone(value) : makeFallback();
  };
  function createDOMPurify() {
    let window2 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
    const DOMPurify = (root) => createDOMPurify(root);
    DOMPurify.version = "3.4.17";
    DOMPurify.removed = [];
    if (!window2 || !window2.document || window2.document.nodeType !== NODE_TYPE.document || !window2.Element) {
      DOMPurify.isSupported = false;
      return DOMPurify;
    }
    let document2 = window2.document;
    const originalDocument = document2;
    const currentScript = originalDocument.currentScript;
    window2.DocumentFragment;
    const HTMLTemplateElement = window2.HTMLTemplateElement, Node = window2.Node, Element2 = window2.Element, NodeFilter = window2.NodeFilter;
    window2.NamedNodeMap === void 0 && (window2.NamedNodeMap || window2.MozNamedAttrMap);
    window2.HTMLFormElement;
    const DOMParser = window2.DOMParser, trustedTypes = window2.trustedTypes;
    const ElementPrototype = Element2.prototype;
    const cloneNode = lookupGetter(ElementPrototype, "cloneNode");
    const remove = lookupGetter(ElementPrototype, "remove");
    const removeAttributeNode = lookupGetter(ElementPrototype, "removeAttributeNode");
    const getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
    const getChildNodes = lookupGetter(ElementPrototype, "childNodes");
    const getParentNode = lookupGetter(ElementPrototype, "parentNode");
    const getShadowRoot = lookupGetter(ElementPrototype, "shadowRoot");
    const getAttributes = lookupGetter(ElementPrototype, "attributes");
    const getNodeType = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeType") : null;
    const getNodeName = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeName") : null;
    const getOwnerDocument = Node && Node.prototype ? lookupGetter(Node.prototype, "ownerDocument") : null;
    const _readNodeType = function _readNodeType2(node) {
      return getNodeType ? getNodeType(node) : node.nodeType;
    };
    const _readNodeName = function _readNodeName2(node) {
      return getNodeName ? getNodeName(node) : node.nodeName;
    };
    const getNamespaceURI = lookupAccessor(ElementPrototype, "namespaceURI");
    const _readNamespaceURI = function _readNamespaceURI2(element) {
      return getNamespaceURI ? getNamespaceURI(element) : element.namespaceURI;
    };
    if (typeof HTMLTemplateElement === "function") {
      const template = document2.createElement("template");
      if (template.content && template.content.ownerDocument) document2 = template.content.ownerDocument;
    }
    let trustedTypesPolicy;
    let emptyHTML = "";
    let defaultTrustedTypesPolicy;
    let defaultTrustedTypesPolicyResolved = false;
    let IN_TRUSTED_TYPES_POLICY = 0;
    const _assertNotInTrustedTypesPolicy = function _assertNotInTrustedTypesPolicy2() {
      if (IN_TRUSTED_TYPES_POLICY > 0) throw typeErrorCreate('A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.');
    };
    const _createTrustedHTML = function _createTrustedHTML2(html2) {
      _assertNotInTrustedTypesPolicy();
      IN_TRUSTED_TYPES_POLICY++;
      try {
        return trustedTypesPolicy.createHTML(html2);
      } finally {
        IN_TRUSTED_TYPES_POLICY--;
      }
    };
    const _createTrustedScriptURL = function _createTrustedScriptURL2(scriptUrl) {
      _assertNotInTrustedTypesPolicy();
      IN_TRUSTED_TYPES_POLICY++;
      try {
        return trustedTypesPolicy.createScriptURL(scriptUrl);
      } finally {
        IN_TRUSTED_TYPES_POLICY--;
      }
    };
    const _getDefaultTrustedTypesPolicy = function _getDefaultTrustedTypesPolicy2() {
      if (!defaultTrustedTypesPolicyResolved) {
        defaultTrustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
        defaultTrustedTypesPolicyResolved = true;
      }
      return defaultTrustedTypesPolicy;
    };
    const _document = document2, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
    const importNode = originalDocument.importNode;
    let hooks = _createHooksMap();
    DOMPurify.isSupported = typeof entries === "function" && typeof getParentNode === "function" && implementation && implementation.createHTMLDocument !== void 0;
    const MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, TMPLIT_EXPR$1 = TMPLIT_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE, CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
    let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
    let ALLOWED_TAGS = null;
    const DEFAULT_ALLOWED_TAGS = addToSet({}, [
      ...html$1,
      ...svg$1,
      ...svgFilters,
      ...mathMl$1,
      ...text
    ]);
    let ALLOWED_ATTR = null;
    const DEFAULT_ALLOWED_ATTR = addToSet({}, [
      ...html,
      ...svg,
      ...mathMl,
      ...xml
    ]);
    let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
      tagNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      allowCustomizedBuiltInElements: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: false
      }
    }));
    let FORBID_TAGS = null;
    let FORBID_ATTR = null;
    const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
      tagCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      }
    }));
    let ALLOW_ARIA_ATTR = true;
    let ALLOW_DATA_ATTR = true;
    let ALLOW_UNKNOWN_PROTOCOLS = false;
    let ALLOW_SELF_CLOSE_IN_ATTR = true;
    let SAFE_FOR_TEMPLATES = false;
    let SAFE_FOR_XML = true;
    let WHOLE_DOCUMENT = false;
    let SET_CONFIG = false;
    let SET_CONFIG_ALLOWED_TAGS = null;
    let SET_CONFIG_ALLOWED_ATTR = null;
    let FORCE_BODY = false;
    let RETURN_DOM = false;
    let RETURN_DOM_FRAGMENT = false;
    let RETURN_TRUSTED_TYPE = false;
    let SANITIZE_DOM = true;
    let SANITIZE_NAMED_PROPS = false;
    const SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
    let KEEP_CONTENT = true;
    let IN_PLACE = false;
    let IN_PLACE_VISITED = null;
    let USE_PROFILES = {};
    let FORBID_CONTENTS = null;
    const DEFAULT_FORBID_CONTENTS = addToSet({}, [
      "annotation-xml",
      "audio",
      "colgroup",
      "desc",
      "foreignobject",
      "head",
      "iframe",
      "math",
      "mi",
      "mn",
      "mo",
      "ms",
      "mtext",
      "noembed",
      "noframes",
      "noscript",
      "plaintext",
      "script",
      "selectedcontent",
      "style",
      "svg",
      "template",
      "thead",
      "title",
      "video",
      "xmp"
    ]);
    let DATA_URI_TAGS = null;
    const DEFAULT_DATA_URI_TAGS = addToSet({}, [
      "audio",
      "video",
      "img",
      "source",
      "image",
      "track"
    ]);
    let URI_SAFE_ATTRIBUTES = null;
    const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, [
      "alt",
      "class",
      "for",
      "id",
      "label",
      "name",
      "pattern",
      "placeholder",
      "role",
      "summary",
      "title",
      "value",
      "style",
      "xmlns"
    ]);
    const MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
    const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
    const HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
    let NAMESPACE = HTML_NAMESPACE;
    let IS_EMPTY_INPUT = false;
    let ALLOWED_NAMESPACES = null;
    const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [
      MATHML_NAMESPACE,
      SVG_NAMESPACE,
      HTML_NAMESPACE
    ], stringToString);
    const DEFAULT_MATHML_TEXT_INTEGRATION_POINTS = freeze([
      "mi",
      "mo",
      "mn",
      "ms",
      "mtext"
    ]);
    let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
    const DEFAULT_HTML_INTEGRATION_POINTS = freeze(["annotation-xml"]);
    let HTML_INTEGRATION_POINTS = addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
    const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, [
      "title",
      "style",
      "font",
      "a",
      "script"
    ]);
    let PARSER_MEDIA_TYPE = null;
    const SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
    const DEFAULT_PARSER_MEDIA_TYPE = "text/html";
    let transformCaseFunc = null;
    let CONFIG = null;
    const formElement = document2.createElement("form");
    const isRegexOrFunction = function isRegexOrFunction2(testValue) {
      return testValue instanceof RegExp || testValue instanceof Function;
    };
    const _parseConfig = function _parseConfig2() {
      let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      if (CONFIG && CONFIG === cfg) return;
      if (!cfg || typeof cfg !== "object") cfg = {};
      cfg = clone(cfg);
      PARSER_MEDIA_TYPE = SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
      transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? stringToString : stringToLowerCase;
      ALLOWED_TAGS = _resolveSetOption(cfg, "ALLOWED_TAGS", DEFAULT_ALLOWED_TAGS, { transform: transformCaseFunc });
      ALLOWED_ATTR = _resolveSetOption(cfg, "ALLOWED_ATTR", DEFAULT_ALLOWED_ATTR, { transform: transformCaseFunc });
      ALLOWED_NAMESPACES = _resolveSetOption(cfg, "ALLOWED_NAMESPACES", DEFAULT_ALLOWED_NAMESPACES, { transform: stringToString });
      URI_SAFE_ATTRIBUTES = _resolveSetOption(cfg, "ADD_URI_SAFE_ATTR", DEFAULT_URI_SAFE_ATTRIBUTES, {
        transform: transformCaseFunc,
        base: DEFAULT_URI_SAFE_ATTRIBUTES
      });
      DATA_URI_TAGS = _resolveSetOption(cfg, "ADD_DATA_URI_TAGS", DEFAULT_DATA_URI_TAGS, {
        transform: transformCaseFunc,
        base: DEFAULT_DATA_URI_TAGS
      });
      FORBID_CONTENTS = _resolveSetOption(cfg, "FORBID_CONTENTS", DEFAULT_FORBID_CONTENTS, { transform: transformCaseFunc });
      FORBID_TAGS = _resolveSetOption(cfg, "FORBID_TAGS", clone({}), { transform: transformCaseFunc });
      FORBID_ATTR = _resolveSetOption(cfg, "FORBID_ATTR", clone({}), { transform: transformCaseFunc });
      USE_PROFILES = objectHasOwnProperty(cfg, "USE_PROFILES") ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === "object" ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
      ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
      ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
      ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
      ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false;
      SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
      SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false;
      WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
      RETURN_DOM = cfg.RETURN_DOM || false;
      RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
      RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
      FORCE_BODY = cfg.FORCE_BODY || false;
      SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
      SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
      KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
      IN_PLACE = cfg.IN_PLACE || false;
      IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI;
      NAMESPACE = typeof cfg.NAMESPACE === "string" ? cfg.NAMESPACE : HTML_NAMESPACE;
      MATHML_TEXT_INTEGRATION_POINTS = _resolveObjectOption(cfg, "MATHML_TEXT_INTEGRATION_POINTS", () => addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS));
      HTML_INTEGRATION_POINTS = _resolveObjectOption(cfg, "HTML_INTEGRATION_POINTS", () => addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS));
      const customElementHandling = _resolveObjectOption(cfg, "CUSTOM_ELEMENT_HANDLING", () => create(null));
      CUSTOM_ELEMENT_HANDLING = create(null);
      if (objectHasOwnProperty(customElementHandling, "tagNameCheck") && isRegexOrFunction(customElementHandling.tagNameCheck)) CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck;
      if (objectHasOwnProperty(customElementHandling, "attributeNameCheck") && isRegexOrFunction(customElementHandling.attributeNameCheck)) CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck;
      if (objectHasOwnProperty(customElementHandling, "allowCustomizedBuiltInElements") && typeof customElementHandling.allowCustomizedBuiltInElements === "boolean") CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements;
      seal(CUSTOM_ELEMENT_HANDLING);
      if (SAFE_FOR_TEMPLATES) ALLOW_DATA_ATTR = false;
      if (RETURN_DOM_FRAGMENT) RETURN_DOM = true;
      if (USE_PROFILES) {
        ALLOWED_TAGS = addToSet({}, text);
        ALLOWED_ATTR = create(null);
        if (USE_PROFILES.html === true) {
          addToSet(ALLOWED_TAGS, html$1);
          addToSet(ALLOWED_ATTR, html);
        }
        if (USE_PROFILES.svg === true) {
          addToSet(ALLOWED_TAGS, svg$1);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.svgFilters === true) {
          addToSet(ALLOWED_TAGS, svgFilters);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.mathMl === true) {
          addToSet(ALLOWED_TAGS, mathMl$1);
          addToSet(ALLOWED_ATTR, mathMl);
          addToSet(ALLOWED_ATTR, xml);
        }
      }
      EXTRA_ELEMENT_HANDLING.tagCheck = null;
      EXTRA_ELEMENT_HANDLING.attributeCheck = null;
      if (objectHasOwnProperty(cfg, "ADD_TAGS")) {
        if (typeof cfg.ADD_TAGS === "function") EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
        else if (arrayIsArray(cfg.ADD_TAGS)) {
          if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) ALLOWED_TAGS = clone(ALLOWED_TAGS);
          addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, "ADD_ATTR")) {
        if (typeof cfg.ADD_ATTR === "function") EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
        else if (arrayIsArray(cfg.ADD_ATTR)) {
          if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) ALLOWED_ATTR = clone(ALLOWED_ATTR);
          addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, "ADD_FORBID_CONTENTS") && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
        if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) FORBID_CONTENTS = clone(FORBID_CONTENTS);
        addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
      }
      if (KEEP_CONTENT) ALLOWED_TAGS["#text"] = true;
      if (WHOLE_DOCUMENT) addToSet(ALLOWED_TAGS, [
        "html",
        "head",
        "body"
      ]);
      if (ALLOWED_TAGS.table) {
        addToSet(ALLOWED_TAGS, ["tbody"]);
        delete FORBID_TAGS.tbody;
      }
      if (cfg.TRUSTED_TYPES_POLICY) {
        if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== "function") throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== "function") throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        const previousTrustedTypesPolicy = trustedTypesPolicy;
        trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
        try {
          emptyHTML = _createTrustedHTML("");
        } catch (error) {
          trustedTypesPolicy = previousTrustedTypesPolicy;
          throw error;
        }
      } else if (cfg.TRUSTED_TYPES_POLICY === null) {
        trustedTypesPolicy = void 0;
        emptyHTML = "";
      } else {
        if (trustedTypesPolicy === void 0) trustedTypesPolicy = _getDefaultTrustedTypesPolicy();
        if (trustedTypesPolicy && typeof emptyHTML === "string") emptyHTML = _createTrustedHTML("");
      }
      if (freeze) freeze(cfg);
      CONFIG = cfg;
    };
    const ALL_SVG_TAGS = addToSet({}, [
      ...svg$1,
      ...svgFilters,
      ...svgDisallowed
    ]);
    const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
    const _checkSvgNamespace = function _checkSvgNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "svg";
      if (parent.namespaceURI === MATHML_NAMESPACE) return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
      return Boolean(ALL_SVG_TAGS[tagName]);
    };
    const _checkMathMlNamespace = function _checkMathMlNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === HTML_NAMESPACE) return tagName === "math";
      if (parent.namespaceURI === SVG_NAMESPACE) return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
      return Boolean(ALL_MATHML_TAGS[tagName]);
    };
    const _checkHtmlNamespace = function _checkHtmlNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) return false;
      if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) return false;
      return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
    };
    const _checkValidNamespace = function _checkValidNamespace2(element) {
      const elementNamespace = _readNamespaceURI(element);
      const tagName = stringToLowerCase(_readNodeName(element));
      const parentNode = getParentNode(element);
      let parent;
      let parentTagName;
      if (parentNode && _readNodeType(parentNode) === NODE_TYPE.element) {
        parent = { namespaceURI: _readNamespaceURI(parentNode) };
        parentTagName = stringToLowerCase(_readNodeName(parentNode));
      } else {
        parent = { namespaceURI: NAMESPACE };
        parentTagName = "template";
      }
      if (!ALLOWED_NAMESPACES[elementNamespace]) return false;
      if (elementNamespace === SVG_NAMESPACE) return _checkSvgNamespace(tagName, parent, parentTagName);
      if (elementNamespace === MATHML_NAMESPACE) return _checkMathMlNamespace(tagName, parent, parentTagName);
      if (elementNamespace === HTML_NAMESPACE) return _checkHtmlNamespace(tagName, parent, parentTagName);
      if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && ALLOWED_NAMESPACES[elementNamespace]) return true;
      return false;
    };
    const _forceRemove = function _forceRemove2(node) {
      arrayPush(DOMPurify.removed, { element: node });
      try {
        getParentNode(node).removeChild(node);
      } catch (_) {
        remove(node);
        if (!getParentNode(node)) throw typeErrorCreate("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
      }
    };
    const _stripAttributeNode = function _stripAttributeNode2(element, attribute, name) {
      try {
        removeAttributeNode(element, attribute);
      } catch (_) {
        try {
          element.removeAttribute(name);
        } catch (_2) {
        }
      }
    };
    const _neutralizeRoot = function _neutralizeRoot2(root) {
      _neutralizeSubtree(root);
      const childNodes = getChildNodes(root);
      if (childNodes) arrayForEach(arraySlice(childNodes), (child) => {
        try {
          remove(child);
        } catch (_) {
        }
      });
      const attributes = _readNodeType(root) === NODE_TYPE.element ? getAttributes(root) : null;
      if (attributes) for (let i = attributes.length - 1; i >= 0; --i) {
        const attribute = attributes[i];
        const name = attribute && attribute.name;
        if (typeof name === "string") _stripAttributeNode(root, attribute, name);
      }
    };
    const _removeAttribute = function _removeAttribute2(name, element, attr) {
      if (!attr) try {
        attr = element.getAttributeNode(name);
      } catch (_) {
        attr = null;
      }
      arrayPush(DOMPurify.removed, {
        attribute: attr || null,
        from: element
      });
      try {
        if (attr) removeAttributeNode(element, attr);
        else element.removeAttribute(name);
      } catch (_) {
        try {
          element.removeAttribute(name);
        } catch (_2) {
        }
      }
      if (name === "is") {
        if (RETURN_DOM || RETURN_DOM_FRAGMENT) try {
          _forceRemove(element);
        } catch (_) {
        }
        else try {
          element.setAttribute(name, "");
        } catch (_) {
        }
      }
    };
    const _stripDisallowedAttributes = function _stripDisallowedAttributes2(element) {
      const attributes = getAttributes(element);
      if (!attributes) return;
      for (let i = attributes.length - 1; i >= 0; --i) {
        const attribute = attributes[i];
        const name = attribute && attribute.name;
        if (typeof name !== "string" || ALLOWED_ATTR[transformCaseFunc(name)]) continue;
        _stripAttributeNode(element, attribute, name);
      }
    };
    const _walkTree = function _walkTree2(root, visit) {
      let intoShadow = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
      const stack = [root];
      while (stack.length > 0) {
        const node = stack.pop();
        if (visit(node) === false) continue;
        if (intoShadow && _readNodeType(node) === NODE_TYPE.element) {
          const shadowRoot = getShadowRoot(node);
          if (_isDocumentFragment(shadowRoot)) stack.push(shadowRoot);
        }
        const childNodes = getChildNodes(node);
        if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push(childNodes[i]);
      }
    };
    const _neutralizeSubtree = function _neutralizeSubtree2(root) {
      _walkTree(root, (node) => {
        if (_readNodeType(node) === NODE_TYPE.element) _stripDisallowedAttributes(node);
      });
    };
    const _collectLiveNodes = function _collectLiveNodes2(root) {
      const nodes = [];
      _walkTree(root, (node) => {
        nodes.push(node);
      }, true);
      return nodes;
    };
    const _neutralizeEscapedElements = function _neutralizeEscapedElements2(root, before) {
      const reachable = setCreate();
      arrayForEach(_collectLiveNodes(root), (node) => {
        if (_readNodeType(node) === NODE_TYPE.element) setAdd(reachable, node);
      });
      arrayForEach(before, (node) => {
        if (_readNodeType(node) === NODE_TYPE.element && !setHas(reachable, node)) _stripDisallowedAttributes(node);
      });
    };
    const _neutralizeDiscarded = function _neutralizeDiscarded2(root, before) {
      let rootRemoved = false;
      arrayForEach(DOMPurify.removed, (entry) => {
        if (entry.element) {
          rootRemoved = rootRemoved || entry.element === root;
          _neutralizeSubtree(entry.element);
        }
      });
      _neutralizeEscapedElements(root, before);
      return rootRemoved;
    };
    const MAX_UNVISITED_ROUNDS = 8;
    const _sanitizeUnvisitedNodes = function _sanitizeUnvisitedNodes2(root, before) {
      const visited = IN_PLACE_VISITED;
      let original = null;
      const getOriginal = () => {
        if (!original) {
          original = setCreate();
          arrayForEach(before, (beforeNode) => {
            setAdd(original, beforeNode);
          });
        }
        return original;
      };
      for (let round = 0; ; round++) {
        const live = _collectLiveNodes(root);
        const containers = [root];
        let pending = false;
        arrayForEach(live, (node) => {
          if (_readNodeType(node) === NODE_TYPE.documentFragment) arrayPush(containers, node);
          else if (!pending && !setHas(visited, node)) pending = setHas(getOriginal(), node);
        });
        if (!pending) return;
        if (round >= MAX_UNVISITED_ROUNDS) throw typeErrorCreate("the tree kept changing during in-place sanitization; refusing to return it");
        arrayForEach(containers, (container, index) => {
          _sanitizeUnvisitedIn(container, index > 0, root, getOriginal());
        });
      }
    };
    const _sanitizeUnvisitedIn = function _sanitizeUnvisitedIn2(container, inShadow, root, original) {
      const iterator = _createNodeIterator(container);
      let node;
      while (node = iterator.nextNode()) {
        if (!setHas(original, node) || setHas(IN_PLACE_VISITED, node)) continue;
        if (inShadow) _executeHooks(hooks.uponSanitizeShadowNode, node, null);
        _sanitizeElements(node, root);
        _sanitizeAttributes(node, root);
        if (_isDocumentFragment(node.content)) _sanitizeShadowDOM2(node.content);
      }
    };
    const _markVisited = function _markVisited2(node) {
      if (IN_PLACE_VISITED) setAdd(IN_PLACE_VISITED, node);
    };
    const _isPatchLinkageAttribute = function _isPatchLinkageAttribute2(lcName, lcTag) {
      if (!SAFE_FOR_XML) return false;
      if (lcName === "patchsrc") return true;
      return lcName === "for" && lcTag !== "label" && lcTag !== "output";
    };
    const _neutralizePatchLinkage = function _neutralizePatchLinkage2(root) {
      if (!SAFE_FOR_XML) return;
      _walkTree(root, (node) => {
        const nodeType = _readNodeType(node);
        if (nodeType === NODE_TYPE.processingInstruction || nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, node.data)) {
          try {
            remove(node);
          } catch (_) {
          }
          return false;
        }
        if (nodeType === NODE_TYPE.element) {
          const element = node;
          const lcTag = transformCaseFunc(_readNodeName(node));
          try {
            if (element.hasAttribute && element.hasAttribute("patchsrc")) element.removeAttribute("patchsrc");
            if (element.hasAttribute && element.hasAttribute("for") && _isPatchLinkageAttribute("for", lcTag)) element.removeAttribute("for");
          } catch (_) {
          }
        }
        return true;
      });
    };
    const _initDocument = function _initDocument2(dirty) {
      let doc = null;
      let leadingWhitespace = null;
      if (FORCE_BODY) dirty = "<remove></remove>" + dirty;
      else {
        const matches = stringMatch(dirty, /^[\r\n\t ]+/);
        leadingWhitespace = matches && matches[0];
      }
      if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && NAMESPACE === HTML_NAMESPACE) dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + "</body></html>";
      const dirtyPayload = trustedTypesPolicy ? _createTrustedHTML(dirty) : dirty;
      if (NAMESPACE === HTML_NAMESPACE) try {
        doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
      } catch (_) {
      }
      if (!doc || !doc.documentElement) {
        doc = implementation.createDocument(NAMESPACE, "template", null);
        try {
          doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
        } catch (_) {
        }
      }
      const body = doc.body || doc.documentElement;
      if (dirty && leadingWhitespace) body.insertBefore(document2.createTextNode(leadingWhitespace), body.childNodes[0] || null);
      if (NAMESPACE === HTML_NAMESPACE) return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
      return WHOLE_DOCUMENT ? doc.documentElement : body;
    };
    const _createNodeIterator = function _createNodeIterator2(root) {
      const doc = getOwnerDocument ? getOwnerDocument(root) : root.ownerDocument;
      return createNodeIterator.call(doc || root, root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
    };
    const _stripTemplateExpressions = function _stripTemplateExpressions2(value) {
      value = stringReplace(value, MUSTACHE_EXPR$1, " ");
      value = stringReplace(value, ERB_EXPR$1, " ");
      value = stringReplace(value, TMPLIT_EXPR$1, " ");
      return value;
    };
    const _scrubTemplateExpressions2 = function _scrubTemplateExpressions(node) {
      var _node$querySelectorAl;
      _scrubOwnCharacterData(node);
      const templates = (_node$querySelectorAl = node.querySelectorAll) === null || _node$querySelectorAl === void 0 ? void 0 : _node$querySelectorAl.call(node, "template");
      if (templates) arrayForEach(templates, (tmpl) => {
        if (_isDocumentFragment(tmpl.content)) _scrubTemplateExpressions2(tmpl.content);
      });
    };
    const _scrubOwnCharacterData = function _scrubOwnCharacterData2(node) {
      node.normalize();
      const doc = getOwnerDocument ? getOwnerDocument(node) : node.ownerDocument;
      const walker = createNodeIterator.call(doc || node, node, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_CDATA_SECTION | NodeFilter.SHOW_PROCESSING_INSTRUCTION, null);
      let currentNode = walker.nextNode();
      while (currentNode) {
        currentNode.data = _stripTemplateExpressions(currentNode.data);
        currentNode = walker.nextNode();
      }
    };
    const _isClobbered = function _isClobbered2(element) {
      const realTagName = getNodeName ? getNodeName(element) : null;
      if (typeof realTagName !== "string") return false;
      if (transformCaseFunc(realTagName) !== "form") return false;
      return typeof element.nodeName !== "string" || typeof element.textContent !== "string" || typeof element.removeChild !== "function" || element.attributes !== getAttributes(element) || typeof element.removeAttribute !== "function" || typeof element.removeAttributeNode !== "function" || typeof element.getAttributeNode !== "function" || typeof element.setAttribute !== "function" || typeof element.namespaceURI !== "string" || typeof element.insertBefore !== "function" || typeof element.hasChildNodes !== "function" || element.nodeType !== getNodeType(element) || element.childNodes !== getChildNodes(element);
    };
    const _isDocumentFragment = function _isDocumentFragment2(value) {
      if (!getNodeType || typeof value !== "object" || value === null) return false;
      try {
        return getNodeType(value) === NODE_TYPE.documentFragment;
      } catch (_) {
        return false;
      }
    };
    const _isNode = function _isNode2(value) {
      if (!getNodeType || typeof value !== "object" || value === null) return false;
      try {
        return typeof getNodeType(value) === "number";
      } catch (_) {
        return false;
      }
    };
    function _executeHooks(hooks2, currentNode, data) {
      if (hooks2.length === 0) return;
      arrayForEach(hooks2, (hook) => {
        hook.call(DOMPurify, currentNode, data, CONFIG);
      });
    }
    const _isUnsafeNode = function _isUnsafeNode2(currentNode, tagName) {
      if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.innerHTML)) return true;
      if (SAFE_FOR_XML && LITERAL_TEXT_ELEMENTS[tagName] && _readNodeType(currentNode) === NODE_TYPE.element && _readNamespaceURI(currentNode) === HTML_NAMESPACE && (_isNode(currentNode.firstElementChild) || typeof currentNode.textContent === "string" && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent))) return true;
      if (currentNode.nodeType === NODE_TYPE.processingInstruction) return true;
      if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, currentNode.data)) return true;
      return false;
    };
    const _matchesNameCheck = function _matchesNameCheck2(check, name) {
      if (check instanceof RegExp) return regExpTest(check, name);
      if (check instanceof Function) {
        for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
        return Boolean(check(name, ...args));
      }
      return false;
    };
    const _sanitizeDisallowedNode = function _sanitizeDisallowedNode2(currentNode, tagName, root) {
      if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) return false;
      if (KEEP_CONTENT && !FORBID_CONTENTS[tagName] && !FORBID_CONTENTS[stringToLowerCase(tagName)]) {
        const parentNode = getParentNode(currentNode);
        const childNodes = getChildNodes(currentNode);
        if (childNodes && parentNode) {
          const childCount = childNodes.length;
          for (let i = childCount - 1; i >= 0; --i) {
            const hoisted = currentNode === root ? cloneNode(childNodes[i], true) : childNodes[i];
            parentNode.insertBefore(hoisted, getNextSibling(currentNode));
          }
        }
      }
      _forceRemove(currentNode);
      return true;
    };
    const _forkSharedAllowlist = function _forkSharedAllowlist2(hookList, set, defaultSet, setConfigSet) {
      if (hookList.length === 0) return set;
      return set === defaultSet || set === setConfigSet ? clone(set) : set;
    };
    const _handleHookDetachedNode = function _handleHookDetachedNode2(currentNode, root) {
      if (currentNode === root || getParentNode(currentNode) !== null) return false;
      if (IN_PLACE) _neutralizeSubtree(currentNode);
      return true;
    };
    const _sanitizeElements = function _sanitizeElements2(currentNode, root) {
      _markVisited(currentNode);
      _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
      if (_handleHookDetachedNode(currentNode, root)) return true;
      if (_isClobbered(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      const tagName = transformCaseFunc(_readNodeName(currentNode));
      ALLOWED_TAGS = _forkSharedAllowlist(hooks.uponSanitizeElement, ALLOWED_TAGS, DEFAULT_ALLOWED_TAGS, SET_CONFIG_ALLOWED_TAGS);
      _executeHooks(hooks.uponSanitizeElement, currentNode, {
        tagName,
        allowedTags: ALLOWED_TAGS
      });
      if (_handleHookDetachedNode(currentNode, root)) return true;
      if (_isUnsafeNode(currentNode, tagName)) {
        _forceRemove(currentNode);
        return true;
      }
      if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS[tagName]) {
        const removed = _sanitizeDisallowedNode(currentNode, tagName, root);
        if (removed === false) {
          _executeHooks(hooks.afterSanitizeElements, currentNode, null);
          if (_handleHookDetachedNode(currentNode, root)) return true;
        }
        return removed;
      }
      if (_readNodeType(currentNode) === NODE_TYPE.element && !_checkValidNamespace(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      if ((tagName === "noscript" || tagName === "noembed" || tagName === "noframes") && regExpTest(FALLBACK_TAG_CLOSE, currentNode.innerHTML)) {
        _forceRemove(currentNode);
        return true;
      }
      if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
        const content = _stripTemplateExpressions(currentNode.textContent);
        if (currentNode.textContent !== content) {
          arrayPush(DOMPurify.removed, { element: currentNode.cloneNode() });
          currentNode.textContent = content;
        }
      }
      _executeHooks(hooks.afterSanitizeElements, currentNode, null);
      return _handleHookDetachedNode(currentNode, root);
    };
    const _isValidAttribute = function _isValidAttribute2(lcTag, lcName, value) {
      if (FORBID_ATTR[lcName]) return false;
      if (_isPatchLinkageAttribute(lcName, lcTag)) return false;
      if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document2 || value in formElement)) return false;
      const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
      if (ALLOW_DATA_ATTR && regExpTest(DATA_ATTR$1, lcName)) return true;
      if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName)) return true;
      if (!nameIsPermitted) return _isBasicCustomElement(lcTag) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName, lcTag) || lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && _matchesNameCheck(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value);
      if (URI_SAFE_ATTRIBUTES[lcName]) return true;
      if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) return true;
      if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag]) return true;
      if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) return true;
      return !value;
    };
    const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, [
      "annotation-xml",
      "color-profile",
      "font-face",
      "font-face-format",
      "font-face-name",
      "font-face-src",
      "font-face-uri",
      "missing-glyph"
    ]);
    const _isBasicCustomElement = function _isBasicCustomElement2(tagName) {
      return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
    };
    const _applyTrustedTypesToAttribute = function _applyTrustedTypesToAttribute2(lcTag, lcName, namespaceURI, value) {
      if (trustedTypesPolicy && typeof trustedTypes === "object" && typeof trustedTypes.getAttributeType === "function" && !namespaceURI) switch (trustedTypes.getAttributeType(lcTag, lcName)) {
        case "TrustedHTML":
          return _createTrustedHTML(value);
        case "TrustedScriptURL":
          return _createTrustedScriptURL(value);
      }
      return value;
    };
    const _setAttributeValue = function _setAttributeValue2(currentNode, name, namespaceURI, value) {
      try {
        if (namespaceURI) currentNode.setAttributeNS(namespaceURI, name, value);
        else currentNode.setAttribute(name, value);
        if (_isClobbered(currentNode)) {
          _forceRemove(currentNode);
          return false;
        }
        return true;
      } catch (_) {
        _removeAttribute(name, currentNode);
        return false;
      }
    };
    const _isUnsafeAttributeValue = function _isUnsafeAttributeValue2(name, value) {
      if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) return true;
      return stringToLowerCase(name) === "attributename" && stringMatch(value, "href") !== null;
    };
    const _sanitizeAttributes = function _sanitizeAttributes2(currentNode, root) {
      _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
      if (_handleHookDetachedNode(currentNode, root)) return;
      const attributes = currentNode.attributes;
      if (!attributes || _isClobbered(currentNode)) return;
      ALLOWED_ATTR = _forkSharedAllowlist(hooks.uponSanitizeAttribute, ALLOWED_ATTR, DEFAULT_ALLOWED_ATTR, SET_CONFIG_ALLOWED_ATTR);
      const hookEvent = {
        attrName: "",
        attrValue: "",
        keepAttr: true,
        allowedAttributes: ALLOWED_ATTR,
        forceKeepAttr: void 0
      };
      let l = attributes.length;
      const lcTag = transformCaseFunc(currentNode.nodeName);
      while (l--) {
        const attr = attributes[l];
        const name = attr.name, namespaceURI = attr.namespaceURI, attrValue = attr.value;
        const lcName = transformCaseFunc(name);
        const initValue = attrValue;
        let value = name === "value" ? initValue : stringTrim(initValue);
        let recreatedNamedProp = false;
        hookEvent.attrName = lcName;
        hookEvent.attrValue = value;
        hookEvent.keepAttr = true;
        hookEvent.forceKeepAttr = void 0;
        _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
        value = hookEvent.attrValue;
        if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name") && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
          _removeAttribute(name, currentNode, attr);
          value = SANITIZE_NAMED_PROPS_PREFIX + value;
          recreatedNamedProp = true;
        }
        if (_isUnsafeAttributeValue(name, value)) {
          _removeAttribute(name, currentNode, attr);
          continue;
        }
        if (hookEvent.forceKeepAttr) continue;
        if (!hookEvent.keepAttr) {
          _removeAttribute(name, currentNode, attr);
          continue;
        }
        if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value)) {
          _removeAttribute(name, currentNode, attr);
          continue;
        }
        if (SAFE_FOR_TEMPLATES) value = _stripTemplateExpressions(value);
        if (!_isValidAttribute(lcTag, lcName, value)) {
          _removeAttribute(name, currentNode, attr);
          continue;
        }
        value = _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value);
        if (value !== initValue) {
          if (_setAttributeValue(currentNode, name, namespaceURI, value) && recreatedNamedProp) arrayPop(DOMPurify.removed);
        }
      }
      _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
      _handleHookDetachedNode(currentNode, root);
    };
    const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
      let shadowNode = null;
      const shadowIterator = _createNodeIterator(fragment);
      _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
      while (shadowNode = shadowIterator.nextNode()) {
        _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
        _sanitizeElements(shadowNode, fragment);
        _sanitizeAttributes(shadowNode, fragment);
        if (_isDocumentFragment(shadowNode.content)) _sanitizeShadowDOM2(shadowNode.content);
        if (_readNodeType(shadowNode) === NODE_TYPE.element) {
          const innerSr = getShadowRoot(shadowNode);
          if (_isDocumentFragment(innerSr)) {
            _sanitizeAttachedShadowRoots(innerSr);
            _sanitizeShadowDOM2(innerSr);
          }
        }
      }
      if (SAFE_FOR_TEMPLATES) _scrubOwnCharacterData(fragment);
      _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
    };
    const _sanitizeAttachedShadowRoots = function _sanitizeAttachedShadowRoots2(root) {
      const stack = [{
        node: root,
        shadow: null
      }];
      while (stack.length > 0) {
        const item = stack.pop();
        if (item.shadow) {
          _sanitizeShadowDOM2(item.shadow);
          continue;
        }
        const node = item.node;
        const isElement = _readNodeType(node) === NODE_TYPE.element;
        const childNodes = getChildNodes(node);
        if (childNodes) for (let i = childNodes.length - 1; i >= 0; --i) stack.push({
          node: childNodes[i],
          shadow: null
        });
        if (isElement) {
          const rootName = getNodeName ? getNodeName(node) : null;
          if (typeof rootName === "string" && transformCaseFunc(rootName) === "template") {
            const content = node.content;
            if (_isDocumentFragment(content)) stack.push({
              node: content,
              shadow: null
            });
          }
        }
        if (isElement) {
          const sr = getShadowRoot(node);
          if (_isDocumentFragment(sr)) stack.push({
            node: null,
            shadow: sr
          }, {
            node: sr,
            shadow: null
          });
        }
      }
    };
    DOMPurify.sanitize = function(dirty) {
      let cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      let body = null;
      let importedNode = null;
      let currentNode = null;
      let returnNode = null;
      IS_EMPTY_INPUT = !dirty;
      if (IS_EMPTY_INPUT) dirty = "<!-->";
      if (typeof dirty !== "string" && !_isNode(dirty)) {
        dirty = stringifyValue(dirty);
        if (typeof dirty !== "string") throw typeErrorCreate("dirty is not a string, aborting");
      }
      if (!DOMPurify.isSupported) return dirty;
      if (SET_CONFIG) {
        ALLOWED_TAGS = SET_CONFIG_ALLOWED_TAGS;
        ALLOWED_ATTR = SET_CONFIG_ALLOWED_ATTR;
      } else _parseConfig(cfg);
      if (hooks.uponSanitizeElement.length > 0 || hooks.uponSanitizeAttribute.length > 0) ALLOWED_TAGS = clone(ALLOWED_TAGS);
      if (hooks.uponSanitizeAttribute.length > 0) ALLOWED_ATTR = clone(ALLOWED_ATTR);
      DOMPurify.removed = [];
      const inPlace = IN_PLACE && typeof dirty !== "string" && _isNode(dirty);
      let inPlaceNodes = [];
      const outerVisited = IN_PLACE_VISITED;
      if (inPlace) {
        _neutralizePatchLinkage(dirty);
        const nn = _readNodeName(dirty);
        if (typeof nn === "string") {
          const tagName = transformCaseFunc(nn);
          if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
            _neutralizeRoot(dirty);
            throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
          }
        }
        if (_isClobbered(dirty)) {
          _neutralizeRoot(dirty);
          throw typeErrorCreate("root node is clobbered and cannot be sanitized in-place");
        }
        inPlaceNodes = _collectLiveNodes(dirty);
        IN_PLACE_VISITED = setCreate();
      } else if (_isNode(dirty)) {
        body = _initDocument("<!---->");
        importedNode = body.ownerDocument.importNode(dirty, true);
        if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === "BODY") body = importedNode;
        else if (importedNode.nodeName === "HTML") body = importedNode;
        else body.appendChild(importedNode);
        _sanitizeAttachedShadowRoots(body);
      } else {
        if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && dirty.indexOf("<") === -1) return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(dirty) : dirty;
        body = _initDocument(dirty);
        if (!body) return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
      }
      if (body && FORCE_BODY) _forceRemove(body.firstChild);
      const walkRoot = inPlace ? dirty : body;
      try {
        if (inPlace) _sanitizeAttachedShadowRoots(dirty);
        const nodeIterator = _createNodeIterator(walkRoot);
        while (currentNode = nodeIterator.nextNode()) {
          _sanitizeElements(currentNode, walkRoot);
          _sanitizeAttributes(currentNode, walkRoot);
          if (_isDocumentFragment(currentNode.content)) _sanitizeShadowDOM2(currentNode.content);
        }
        if (inPlace) _sanitizeUnvisitedNodes(dirty, inPlaceNodes);
      } catch (error) {
        if (inPlace) {
          _neutralizeRoot(dirty);
          _neutralizeDiscarded(dirty, inPlaceNodes);
        }
        throw error;
      } finally {
        IN_PLACE_VISITED = outerVisited;
      }
      if (inPlace) {
        if (_neutralizeDiscarded(dirty, inPlaceNodes)) throw typeErrorCreate("a node selected for removal could not be safely returned; refusing to sanitize in place");
        if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(dirty);
        return dirty;
      }
      if (RETURN_DOM) {
        if (SAFE_FOR_TEMPLATES) _scrubTemplateExpressions2(body);
        if (RETURN_DOM_FRAGMENT) {
          returnNode = createDocumentFragment.call(body.ownerDocument);
          while (body.firstChild) returnNode.appendChild(body.firstChild);
        } else returnNode = body;
        if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) returnNode = importNode.call(originalDocument, returnNode, true);
        return returnNode;
      }
      let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
      if (WHOLE_DOCUMENT && ALLOWED_TAGS["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
      if (SAFE_FOR_TEMPLATES) serializedHTML = _stripTemplateExpressions(serializedHTML);
      return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(serializedHTML) : serializedHTML;
    };
    DOMPurify.setConfig = function() {
      let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      _parseConfig(cfg);
      SET_CONFIG = true;
      SET_CONFIG_ALLOWED_TAGS = ALLOWED_TAGS;
      SET_CONFIG_ALLOWED_ATTR = ALLOWED_ATTR;
    };
    DOMPurify.clearConfig = function() {
      CONFIG = null;
      SET_CONFIG = false;
      SET_CONFIG_ALLOWED_TAGS = null;
      SET_CONFIG_ALLOWED_ATTR = null;
      trustedTypesPolicy = defaultTrustedTypesPolicy;
      emptyHTML = "";
    };
    DOMPurify.isValidAttribute = function(tag, attr, value) {
      if (!CONFIG) _parseConfig({});
      const lcTag = transformCaseFunc(tag);
      const lcName = transformCaseFunc(attr);
      if (typeof value === "string" && (_isUnsafeAttributeValue(attr, value) || !ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value))) return false;
      return _isValidAttribute(lcTag, lcName, value);
    };
    DOMPurify.addHook = function(entryPoint, hookFunction) {
      if (typeof hookFunction !== "function") return;
      if (!objectHasOwnProperty(hooks, entryPoint)) return;
      arrayPush(hooks[entryPoint], hookFunction);
    };
    DOMPurify.removeHook = function(entryPoint, hookFunction) {
      if (!objectHasOwnProperty(hooks, entryPoint)) return;
      if (hookFunction !== void 0) {
        const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
        return index === -1 ? void 0 : arraySplice(hooks[entryPoint], index, 1)[0];
      }
      return arrayPop(hooks[entryPoint]);
    };
    DOMPurify.removeHooks = function(entryPoint) {
      if (!objectHasOwnProperty(hooks, entryPoint)) return;
      hooks[entryPoint] = [];
    };
    DOMPurify.removeAllHooks = function() {
      hooks = _createHooksMap();
    };
    return DOMPurify;
  }
  var purify_default = createDOMPurify();

  // src/enhancer/renderer.ts
  var zenuml = globalThis["mermaid-zenuml"];
  var diagramsReady = mermaid.registerExternalDiagrams([zenuml], { lazyLoad: true });
  var chain = Promise.resolve();
  var counter = 0;
  function normalizeAgentflow(code) {
    const frontmatter = code.match(/^\s*---[ \t]*\r?\n(?:[^\r\n]*\r?\n)*?---[ \t]*\r?\n/)?.[0] ?? "";
    const body = code.slice(frontmatter.length);
    return frontmatter + body.replace(/^((?:[ \t]*(?:%%[^\r\n]*)?\r?\n)*[ \t]*)agentflow(?=\s|$)/, "$1agentflow-beta");
  }
  async function renderOnce(code, theme, securityLevel) {
    const id = `mlens-${Date.now().toString(36)}-${counter++}`;
    mermaid.initialize({
      startOnLoad: false,
      securityLevel,
      suppressErrorRendering: true,
      theme,
      // Mermaid 12's dark themes stroke node borders with a gradient and add grey
      // drop shadows; we want plain, solid borders.
      themeVariables: { useGradient: false, dropShadow: "" }
    });
    try {
      const { svg: svg2, diagramType } = await mermaid.render(id, code);
      return { svg: svg2, diagramType };
    } finally {
      for (const prefix of ["d", "i", ""]) document.getElementById(prefix + id)?.closest("body > *")?.remove();
    }
  }
  function renderMermaid(code, theme) {
    const job = chain.then(async () => {
      await diagramsReady;
      const source = normalizeAgentflow(code);
      try {
        const out = await renderOnce(source, theme, "sandbox");
        return { svg: unwrapSandbox(out.svg), diagramType: out.diagramType };
      } catch {
        return renderOnce(source, theme, "strict");
      }
    });
    chain = job.catch(() => {
    });
    return job;
  }
  function unwrapSandbox(markup) {
    const b64 = markup.match(/src="data:text\/html;[^,"]*base64,([^"]+)"/)?.[1];
    let html2 = markup;
    if (b64) {
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      html2 = new TextDecoder().decode(bytes);
    }
    const svg2 = html2.match(/<svg[\s\S]*<\/svg>/)?.[0];
    if (!svg2) throw new Error("Mermaid returned no SVG");
    return purify_default.sanitize(svg2, {
      ADD_TAGS: ["foreignobject"],
      ADD_ATTR: ["dominant-baseline"],
      HTML_INTEGRATION_POINTS: { foreignobject: true }
    });
  }
  function isDarkBehind(el) {
    const html2 = document.documentElement;
    const mode = html2.getAttribute("data-color-mode");
    if (mode === "dark") return true;
    if (mode === "light") return false;
    if (mode === "auto") return matchMedia("(prefers-color-scheme: dark)").matches;
    return luminance(pageBackground(el)) < 0.4;
  }
  function pageBackground(el) {
    for (let cur = el; cur; cur = cur.parentElement) {
      const bg = getComputedStyle(cur).backgroundColor;
      if (bg && !/rgba\(.*,\s*0\)$|transparent/.test(bg)) return bg;
    }
    const bodyBg = document.body ? getComputedStyle(document.body).backgroundColor : "";
    if (bodyBg && !/rgba\(.*,\s*0\)$|transparent/.test(bodyBg)) return bodyBg;
    return matchMedia("(prefers-color-scheme: dark)").matches ? "rgb(13, 17, 23)" : "rgb(255, 255, 255)";
  }
  function luminance(color) {
    const m = color.match(/[\d.]+/g);
    if (!m) return 1;
    const [r, g, b] = m.map(Number);
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }

  // src/enhancer/sequence.ts
  function inRange(range, y) {
    return range.top <= y && y < range.bottom;
  }
  function compatible(a, b) {
    return a.every((first) => b.every((second) => first.decision !== second.decision || first === second));
  }
  function extractSequence(svg2) {
    const nodes = [];
    const edges = [];
    const byElement = /* @__PURE__ */ new Map();
    function addPart(node, el, styleClass) {
      if (byElement.has(el)) return;
      if (el !== node.el) (node.parts ??= []).push(el);
      el.classList.add("ml-sequence-target", styleClass);
      byElement.set(el, node);
    }
    function addNode(el, styleClass) {
      const node = { kind: "node", id: String(nodes.length), el, cluster: false, in: [], out: [] };
      nodes.push(node);
      addPart(node, el, styleClass);
      return node;
    }
    const participants = /* @__PURE__ */ new Map();
    const lifelines = /* @__PURE__ */ new Map();
    for (const el of svg2.querySelectorAll('[data-et="participant"], .actor-top, .actor-bottom, line.actor-line')) {
      const part = el.closest('[data-et="participant"]') ?? (el.localName === "rect" ? el.closest("g") : el);
      const id = part?.dataset.id ?? el.getAttribute("name");
      if (!id || !part) continue;
      const node = participants.get(id) ?? addNode(part, "ml-sequence-participant");
      participants.set(id, node);
      addPart(node, part, "ml-sequence-participant");
      if (el instanceof SVGLineElement) lifelines.set(node, el.x1.baseVal.value);
    }
    function endpoint(id, x) {
      if (id !== void 0) return participants.get(id);
      let nearest;
      let distance = Infinity;
      for (const [node, center] of lifelines) {
        const offset = Math.abs(center - x);
        if (offset < distance) {
          nearest = node;
          distance = offset;
        }
      }
      return nearest;
    }
    const branches = [];
    const ranges = /* @__PURE__ */ new Map();
    for (const label of svg2.querySelectorAll("text.labelText")) {
      if (label.textContent?.trim() !== "alt") continue;
      const frame = label.parentElement;
      const lines = [...frame.querySelectorAll(":scope > line.loopLine")].filter((el) => el.y1.baseVal.value === el.y2.baseVal.value && el.x1.baseVal.value !== el.x2.baseVal.value).sort((a, b) => a.y1.baseVal.value - b.y1.baseVal.value);
      if (lines.length < 2) continue;
      const decision = addNode(label, "ml-sequence-guard");
      const badge = frame.querySelector(".labelBox");
      if (badge) addPart(decision, badge, "ml-sequence-divider");
      ranges.set(decision, { top: lines[0].y1.baseVal.value, bottom: lines.at(-1).y1.baseVal.value });
      const choices = [];
      for (let i = 0; i < lines.length - 1; i++) {
        const line = lines[i];
        const top = line.y1.baseVal.value;
        const bottom = lines[i + 1].y1.baseVal.value;
        const node = addNode(line, "ml-sequence-divider");
        const branch = { top, bottom, node, decision };
        ranges.set(node, branch);
        choices.push(branch);
      }
      for (const title of frame.querySelectorAll(":scope > .loopText, :scope > .sectionTitle")) {
        const box = title.getBBox();
        const branch = choices.find((choice) => inRange(choice, box.y + box.height / 2));
        if (branch) addPart(branch.node, title, "ml-sequence-guard");
      }
      branches.push(...choices);
    }
    const times = /* @__PURE__ */ new Map();
    const contexts = /* @__PURE__ */ new Map();
    const byBranchIds = /* @__PURE__ */ new Map();
    const addLabel = (edge, label) => {
      edge.labels.push(label);
      label.classList.add("ml-elabel", "ml-sequence-target");
      byElement.set(label, edge);
    };
    for (const el of svg2.querySelectorAll(":is(line, path):is(.messageLine0, .messageLine1)")) {
      const length = el.getTotalLength();
      if (!length) continue;
      const start = el.getPointAtLength(0);
      const end = el.getPointAtLength(length);
      const edge = {
        kind: "edge",
        el,
        labels: [],
        from: endpoint(el.dataset.from, start.x),
        to: endpoint(el.dataset.to, end.x)
      };
      edge.from?.out.push(edge);
      edge.to?.in.push(edge);
      el.classList.add("ml-edge", "ml-sequence-target");
      byElement.set(el, edge);
      edges.push(edge);
      times.set(edge, start.y);
      const enclosing = branches.filter((branch) => inRange(branch, start.y));
      const key = enclosing.map(({ node }) => node.id).join(",");
      if (!byBranchIds.has(key)) byBranchIds.set(key, enclosing);
      contexts.set(edge, byBranchIds.get(key));
      for (let prev = el.previousElementSibling; prev?.matches(".messageText"); prev = prev.previousElementSibling) {
        addLabel(edge, prev);
      }
      let next = el.nextElementSibling;
      if (next?.matches("g:has(> circle[cy])")) {
        addLabel(edge, next);
        next = next.nextElementSibling;
      }
      if (next?.matches('line[marker-start$="-sequencenumber)"]') && next.nextElementSibling?.matches(".sequenceNumber")) {
        addLabel(edge, next);
        addLabel(edge, next.nextElementSibling);
      }
    }
    if (!edges.length && !nodes.length) return null;
    addHitAreas(edges, byElement);
    const forward = [...edges].sort((a, b) => times.get(a) - times.get(b));
    const backward = [...forward].reverse();
    const expand2 = (selection, mode, direction) => {
      const litNodes = new Set(selection.nodes);
      const litEdges = /* @__PURE__ */ new Set();
      const trace = (starting, scope) => {
        starting.forEach((edge) => litEdges.add(edge));
        if (mode !== "flow" || !starting.length) return;
        const seeds = new Set(starting);
        const walk = (ordered, enter, leave) => {
          const reached = /* @__PURE__ */ new Map();
          for (const edge of ordered) {
            const branchPath = contexts.get(edge);
            if (!compatible(scope, branchPath)) continue;
            const [entry, exit] = [edge[enter], edge[leave]];
            if (!seeds.has(edge) && (!entry || ![...reached.get(entry) ?? []].some((prev) => compatible(prev, branchPath)))) continue;
            litEdges.add(edge);
            if (!exit) continue;
            const paths2 = reached.get(exit) ?? /* @__PURE__ */ new Set();
            paths2.add(branchPath);
            reached.set(exit, paths2);
          }
        };
        if (direction !== "up") walk(forward, "from", "to");
        if (direction !== "down") walk(backward, "to", "from");
      };
      for (const edge of selection.edges) trace([edge], contexts.get(edge));
      for (const node of selection.nodes) {
        const range = ranges.get(node);
        if (range) {
          const scope = branches.filter((branch) => branch.top <= range.top && range.bottom <= branch.bottom);
          for (const branch of scope) {
            litNodes.add(branch.node);
            litNodes.add(branch.decision);
          }
          trace(forward.filter((edge) => inRange(range, times.get(edge))), scope);
        } else {
          trace([
            ...direction !== "up" ? node.out : [],
            ...direction !== "down" ? node.in : []
          ], []);
        }
      }
      for (const edge of litEdges) {
        if (edge.from) litNodes.add(edge.from);
        if (edge.to) litNodes.add(edge.to);
        for (const { node, decision } of contexts.get(edge)) {
          litNodes.add(node);
          litNodes.add(decision);
        }
      }
      return { nodes: litNodes, edges: litEdges };
    };
    return { nodes, edges, byElement, expand: expand2 };
  }

  // src/enhancer/styles.ts
  var BASE_CSS = (
    /* css */
    `
:host {
  all: initial;
  display: block;
  position: relative;
  --ml-hl: #f59e0b;
  --ml-accent: #6366f1;
  --ml-text: #1f2328;
  --ml-muted: #59636e;
  --ml-surface: rgba(255, 255, 255, 0.82);
  --ml-surface-solid: #ffffff;
  --ml-border: rgba(31, 35, 40, 0.12);
  --ml-border-strong: rgba(31, 35, 40, 0.24);
  --ml-hover: rgba(31, 35, 40, 0.06);
  --ml-active-bg: rgba(99, 102, 241, 0.12);
  --ml-tip-bg: #1f2328;
  --ml-tip-fg: #ffffff;
  --ml-shadow: 0 1px 2px rgba(31, 35, 40, 0.06), 0 6px 20px rgba(31, 35, 40, 0.10);
  --ml-shadow-lg: 0 2px 6px rgba(31, 35, 40, 0.08), 0 16px 40px rgba(31, 35, 40, 0.16);
  --ml-page-bg: #ffffff;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, "Noto Sans", Helvetica, Arial, sans-serif;
  font-size: 13px;
  line-height: 1.4;
  color: var(--ml-text);
}
:host([data-ui="dark"]) {
  --ml-accent: #8b93ff;
  --ml-text: #e6edf3;
  --ml-muted: #9198a1;
  --ml-surface: rgba(22, 27, 34, 0.82);
  --ml-surface-solid: #161b22;
  --ml-border: rgba(240, 246, 252, 0.12);
  --ml-border-strong: rgba(240, 246, 252, 0.26);
  --ml-hover: rgba(240, 246, 252, 0.07);
  --ml-active-bg: rgba(139, 147, 255, 0.16);
  --ml-tip-bg: #e6edf3;
  --ml-tip-fg: #0d1117;
  --ml-shadow: 0 1px 2px rgba(0, 0, 0, 0.3), 0 6px 20px rgba(0, 0, 0, 0.35);
  --ml-shadow-lg: 0 2px 6px rgba(0, 0, 0, 0.35), 0 16px 40px rgba(0, 0, 0, 0.5);
}
:host(:fullscreen) { background: var(--ml-page-bg); }

* { box-sizing: border-box; }

.frame {
  position: relative;
  height: 240px;
  border-radius: 10px;
  outline: none;
  container-type: inline-size;
}
/* No border: the diagram sits directly on the page. Keyboard focus still gets a ring. */
.frame:focus-visible:not([data-pointer]) { outline: 2px solid var(--ml-accent); outline-offset: 2px; }
:host(:fullscreen) .frame { height: 100% !important; border-radius: 0; outline: none; }

.viewport {
  position: absolute;
  inset: 0;
  overflow: hidden;
  border-radius: inherit;
  cursor: grab;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}
.viewport.grabbing { cursor: grabbing; }
.viewport {
  /* Match the blank document Mermaid measured text in (see renderer.ts). */
  font: initial;
  line-height: normal;
  color: initial;
  letter-spacing: normal;
}
.viewport > svg { display: block; width: 100%; height: 100%; max-width: none !important; }

/* ---------- floating UI ---------- */
.ui { opacity: 0; transform: translateY(-2px); transition: opacity 0.16s ease, transform 0.16s ease; pointer-events: none; }
.frame:hover .ui, .frame:focus-within .ui, .frame.engaged .ui, :host(:fullscreen) .ui {
  opacity: 1; transform: none; pointer-events: auto;
}
.bar {
  position: absolute;
  z-index: 3;
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px;
  background: var(--ml-surface);
  -webkit-backdrop-filter: blur(14px) saturate(1.5);
  backdrop-filter: blur(14px) saturate(1.5);
  border: 1px solid var(--ml-border);
  border-radius: 12px;
  box-shadow: var(--ml-shadow);
}
.toolbar { top: 10px; right: 10px; }
.zoombar { bottom: 10px; right: 10px; padding: 3px; border-radius: 10px; }
.sep { width: 1px; align-self: stretch; margin: 5px 3px; background: var(--ml-border); }

button { font: inherit; color: inherit; }
.btn, .zoom-label {
  all: unset;
  box-sizing: border-box;
  position: relative;
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 8px;
  color: var(--ml-muted);
  cursor: pointer;
  transition: background 0.12s ease, color 0.12s ease;
}
.btn.sm { width: 26px; height: 26px; border-radius: 7px; }
.zoom-label {
  width: auto;
  min-width: 46px;
  height: 26px;
  padding: 0 4px;
  font: 500 11.5px/1 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-variant-numeric: tabular-nums;
  text-align: center;
}
.btn:hover, .zoom-label:hover { background: var(--ml-hover); color: var(--ml-text); }
.btn:focus-visible, .zoom-label:focus-visible, .item:focus-visible, .seg button:focus-visible, .swatch:focus-visible {
  outline: 2px solid var(--ml-accent); outline-offset: -2px;
}
.btn.on, .btn[aria-expanded="true"] { background: var(--ml-active-bg); color: var(--ml-accent); }
.btn .dot {
  position: absolute; right: 4px; bottom: 4px; width: 7px; height: 7px; border-radius: 50%;
  background: var(--ml-hl); box-shadow: 0 0 0 1.5px var(--ml-surface-solid); display: none;
}
.btn.on .dot { display: block; }

[data-tip]:hover::after {
  content: attr(data-tip);
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  z-index: 6;
  white-space: nowrap;
  font: 500 11.5px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  padding: 5px 8px;
  border-radius: 6px;
  background: var(--ml-tip-bg);
  color: var(--ml-tip-fg);
  pointer-events: none;
  animation: ml-tip 0.12s ease 0.4s both;
}
.zoombar [data-tip]:hover::after { top: auto; bottom: calc(100% + 8px); }
[aria-expanded="true"][data-tip]:hover::after { display: none; }
@keyframes ml-tip { from { opacity: 0; transform: translateY(-2px); } }

.hint {
  position: absolute;
  left: 10px;
  bottom: 10px;
  z-index: 2;
  max-width: calc(100% - 200px);
  padding: 5px 9px;
  font-size: 11.5px;
  color: var(--ml-muted);
  background: var(--ml-surface);
  -webkit-backdrop-filter: blur(14px);
  backdrop-filter: blur(14px);
  border: 1px solid var(--ml-border);
  border-radius: 8px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  opacity: 0;
  transform: translateY(4px);
  transition: opacity 0.2s ease, transform 0.2s ease;
  pointer-events: none;
}
.hint.show { opacity: 1; transform: none; }
@container (max-width: 520px) { .hint { display: none; } }
kbd {
  font: 500 10.5px/1 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  padding: 2px 4px;
  border-radius: 4px;
  border: 1px solid var(--ml-border-strong);
  border-bottom-width: 2px;
}

/* ---------- popovers ---------- */
.pop {
  position: absolute;
  top: 56px;
  right: 10px;
  z-index: 5;
  width: 272px;
  padding: 14px;
  background: var(--ml-surface-solid);
  border: 1px solid var(--ml-border);
  border-radius: 12px;
  box-shadow: var(--ml-shadow-lg);
  display: none;
}
.pop.open { display: block; animation: ml-pop 0.14s ease-out; }
@keyframes ml-pop { from { opacity: 0; transform: translateY(-4px) scale(0.98); } }
.pop.menu { padding: 6px; width: 260px; }
.pop h4 {
  margin: 0 0 8px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--ml-muted);
}
.row { margin-top: 14px; }
.seg {
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: 1fr;
  gap: 2px;
  padding: 2px;
  background: var(--ml-hover);
  border-radius: 8px;
  transition: opacity 0.15s;
}
.seg button {
  all: unset;
  padding: 6px 4px;
  border-radius: 6px;
  text-align: center;
  font-size: 12px;
  font-weight: 500;
  color: var(--ml-muted);
  cursor: pointer;
}
.seg button:hover { color: var(--ml-text); }
.seg button[aria-checked="true"] {
  background: var(--ml-surface-solid);
  color: var(--ml-text);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12), 0 0 0 1px var(--ml-border);
}
.seg.disabled { opacity: 0.4; pointer-events: none; }
.swatches { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.swatch {
  all: unset;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--c);
  cursor: pointer;
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.14);
  transition: transform 0.1s ease, box-shadow 0.1s ease;
}
.swatch:hover { transform: scale(1.12); }
.swatch[aria-checked="true"] { box-shadow: 0 0 0 2px var(--ml-surface-solid), 0 0 0 4px var(--c); }
.custom {
  position: relative;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: conic-gradient(#ef4444, #f59e0b, #eab308, #22c55e, #06b6d4, #6366f1, #a855f7, #ec4899, #ef4444);
  cursor: pointer;
}
.custom[aria-checked="true"] { box-shadow: 0 0 0 2px var(--ml-surface-solid), 0 0 0 4px var(--ml-hl); }
.custom input { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; border: 0; padding: 0; cursor: pointer; }
.timing + .timing { margin-top: 16px; }
.timing .head { display: flex; align-items: baseline; justify-content: space-between; margin-bottom: 6px; }
.timing .head h4 { margin: 0; }
.timing output { font: 500 11.5px/1 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-variant-numeric: tabular-nums; color: var(--ml-text); }
.timing input[type="range"] { width: 100%; margin: 0; accent-color: var(--ml-accent); cursor: pointer; }
.timing .scale { display: flex; justify-content: space-between; margin-top: 2px; font-size: 10.5px; color: var(--ml-muted); }
.note { margin: 14px 0 0; font-size: 11.5px; line-height: 1.5; color: var(--ml-muted); }

.item {
  all: unset;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 13px;
  color: var(--ml-text);
  cursor: pointer;
}
.item:hover { background: var(--ml-hover); }
.item > svg { flex: none; color: var(--ml-muted); }
.item[disabled] { opacity: 0.4; pointer-events: none; }
.item .label { flex: 1; min-width: 0; }
.item .sub { display: block; margin-top: 1px; font-size: 11.5px; color: var(--ml-muted); }
.divider { height: 1px; margin: 6px 4px; background: var(--ml-border); }
.switch {
  flex: none;
  position: relative;
  width: 30px;
  height: 18px;
  border-radius: 9px;
  background: var(--ml-border-strong);
  transition: background 0.15s ease;
}
.switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
  transition: transform 0.15s ease;
}
[aria-checked="true"] > .switch { background: var(--ml-accent); }
[aria-checked="true"] > .switch::after { transform: translateX(12px); }

.toast {
  position: absolute;
  left: 50%;
  bottom: 14px;
  z-index: 6;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 7px 12px 7px 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ml-tip-fg);
  background: var(--ml-tip-bg);
  border-radius: 999px;
  box-shadow: var(--ml-shadow);
  opacity: 0;
  transform: translate(-50%, 6px);
  transition: opacity 0.18s ease, transform 0.18s ease;
  pointer-events: none;
  white-space: nowrap;
}
.toast.show { opacity: 1; transform: translate(-50%, 0); }

/* ---------- diagram: outlines ---------- */
/* Softer than Mermaid's defaults; lit items return to full strength below. */
svg g.node :is(rect, polygon, circle, ellipse, path, line),
svg g.cluster > :is(rect, polygon, path),
svg :is(rect.actor, rect.note, rect.labelBox) { stroke-opacity: 0.4; transition: stroke-opacity 0.18s ease; }
svg g.node.ml-on :is(rect, polygon, circle, ellipse, path, line),
svg g.cluster.ml-on > :is(rect, polygon, path) { stroke-opacity: 1; }

/* ---------- diagram: highlight ---------- */
svg .ml-hit { fill: none !important; stroke: transparent !important; stroke-width: 14px !important; pointer-events: stroke; }
svg g.node, svg g.cluster, svg .ml-edge, svg .ml-elabel { transition: opacity 0.18s ease; }
svg g.node > *, svg g.cluster > *, svg .ml-edge { transition: opacity 0.18s ease, stroke 0.18s ease, stroke-width 0.18s ease; }
svg.ml-hl-enabled g.node, svg.ml-hl-enabled .ml-hit, svg.ml-hl-enabled .ml-elabel, svg.ml-hl-enabled .cluster-label { cursor: pointer; }
svg.ml-has-hl g.node:not(.ml-on),
svg.ml-has-hl .ml-edge:not(.ml-on),
svg.ml-has-hl .ml-elabel:not(.ml-on) { opacity: 0.25; }
svg.ml-has-hl g.cluster:not(.ml-on) { opacity: 0.55; }
svg g.node.ml-on > :is(rect, polygon, circle, ellipse, path),
svg g.node.ml-on > g:not(.label) :is(rect, polygon, circle, ellipse, path),
svg g.cluster.ml-on > :is(rect, polygon, path) {
  stroke: var(--ml-hl) !important;
  stroke-width: 1.5px !important;
}
/* The hovered / pinned item: a slightly heavier outline and a faint, tight shadow \u2014 no glow. */
svg g.node.ml-sel > :is(rect, polygon, circle, ellipse, path),
svg g.node.ml-sel > g:not(.label) :is(rect, polygon, circle, ellipse, path),
svg g.cluster.ml-sel > :is(rect, polygon, path) { stroke-width: 2px !important; }
svg g.node.ml-sel, svg g.cluster.ml-sel {
  filter: drop-shadow(0 1px 2px color-mix(in srgb, var(--ml-hl) 22%, transparent));
}
svg .ml-edge.ml-on { stroke: var(--ml-hl) !important; stroke-width: 2px !important; }
svg .ml-edge.ml-sel { stroke-width: 2.5px !important; }

/* ---------- sequence diagrams ---------- */
svg.ml-hl-enabled .ml-sequence-target { cursor: pointer; }
svg.ml-has-hl :is(.ml-sequence-guard, .ml-sequence-divider, .ml-sequence-participant):not(.ml-on) { opacity: 0.35; }
svg :is(.ml-sequence-divider, line.ml-sequence-participant).ml-on,
svg .ml-sequence-participant.ml-on :is(rect, circle, line, polygon, path) {
  stroke: var(--ml-hl) !important;
  stroke-opacity: 1;
}
svg .ml-sequence-divider.ml-on { stroke-width: 2px !important; }

/* ---------- diagram: flowing edges ---------- */
svg.ml-flowing:not(.ml-has-hl) .ml-edge,
svg.ml-flowing.ml-has-hl .ml-edge.ml-on {
  stroke-dasharray: 9 7 !important;
  animation: ml-flow var(--ml-flow-duration, 1.5s) linear infinite !important;
}
@keyframes ml-flow { to { stroke-dashoffset: -16; } }
`
  );

  // src/enhancer/viewer.ts
  var PAD = 16;
  var MIN_HEIGHT = 140;
  var MOD = /Mac|iPhone|iPad/.test(navigator.platform) ? "\u2318" : "Ctrl";
  var HINT = `Drag to pan \xB7 <kbd>${MOD}</kbd> + scroll to zoom \xB7 Hover to highlight, click to pin`;
  var HOVER_OUT_MS = 90;
  var baseSheet;
  function getBaseSheet() {
    if (!baseSheet) {
      baseSheet = new CSSStyleSheet();
      baseSheet.replaceSync(BASE_CSS);
    }
    return baseSheet;
  }
  var SHADOW_CSS = /filter\s*:\s*(?:drop-shadow\([^;}]*|url\([^)]*shadow[^)]*\))\s*;?/gi;
  function flattenStyles(svg2, css) {
    const shadowFilters = [...svg2.querySelectorAll("filter")].filter((f) => /shadow/i.test(f.id));
    const ids = new Set(shadowFilters.map((f) => f.id));
    shadowFilters.forEach((f) => f.remove());
    const isShadow = (v) => /drop-shadow\(/i.test(v) || [...ids].some((id) => v.includes(`#${id}`));
    for (const el of svg2.querySelectorAll('[filter], [style*="filter"]')) {
      const attr = el.getAttribute("filter");
      if (attr && isShadow(attr)) el.removeAttribute("filter");
      const inline = el.style.getPropertyValue("filter");
      if (inline && isShadow(inline)) el.style.removeProperty("filter");
    }
    css = css.replace(SHADOW_CSS, "filter: none;");
    for (const g of svg2.querySelectorAll("linearGradient, radialGradient")) {
      if (!/gradient$/i.test(g.id)) continue;
      const colour = g.querySelector("stop")?.getAttribute("stop-color");
      if (!colour) continue;
      const ref = new RegExp(`url\\(\\s*["']?#${g.id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["']?\\s*\\)`, "g");
      css = css.replace(ref, colour);
    }
    return css;
  }
  var esc = (s) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
  var clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  var HL_LABEL = { neighbors: "Connected", flow: "Full flow", off: "Off" };
  var secs = (v) => `${v.toFixed(1)}s`;
  var DiagramViewer = class {
    constructor(source, ctx) {
      this.source = source;
      this.ctx = ctx;
    }
    source;
    ctx;
    host = document.createElement(HOST_TAG);
    mounted = false;
    root = this.host.attachShadow({ mode: "open" });
    diagramSheet = new CSSStyleSheet();
    frame;
    viewport;
    zoomLabel;
    hint;
    toastEl;
    svg;
    styleText = "";
    diagramType = "";
    natural = { x: 0, y: 0, w: 1, h: 1 };
    view = { x: 0, y: 0, k: 1 };
    size = { w: 0, h: 0 };
    lastWidth = 0;
    pristine = true;
    fullscreen = false;
    renderedTheme = "";
    dark = false;
    graph;
    highlighter;
    build;
    openPop;
    pointers = /* @__PURE__ */ new Map();
    drag;
    pinch;
    hintTimer = 0;
    toastTimer = 0;
    hoverTimer = 0;
    hintShownAt = 0;
    ro;
    prevDisplay = ["", ""];
    cleanups = [];
    // ------------------------------------------------------------------ lifecycle
    async mount() {
      this.dark = isDarkBehind(this.source.anchor);
      let markup;
      try {
        markup = await this.produceSvg();
      } catch (err) {
        console.debug("[Mermaid Lens] could not render diagram", err);
        return false;
      }
      const anchor = this.source.anchor;
      if (!anchor.isConnected) return false;
      this.buildUi();
      this.setSvg(markup);
      this.applySettings(this.ctx.settings());
      const cs = getComputedStyle(anchor);
      this.host.style.margin = cs.margin;
      if (cs.display === "none") this.host.style.display = "none";
      anchor.before(this.host);
      this.prevDisplay = [anchor.style.getPropertyValue("display"), anchor.style.getPropertyPriority("display")];
      anchor.style.setProperty("display", "none", "important");
      this.ro = new ResizeObserver(() => this.onResize());
      this.ro.observe(this.frame);
      this.mounted = true;
      return true;
    }
    destroy() {
      this.ro?.disconnect();
      this.build?.stop();
      this.cleanups.forEach((c) => c());
      this.cleanups = [];
      if (document.fullscreenElement === this.host) void document.exitFullscreen().catch(() => {
      });
      this.host.remove();
      const [value, priority] = this.prevDisplay;
      if (this.mounted) {
        if (value) this.source.anchor.style.setProperty("display", value, priority);
        else this.source.anchor.style.removeProperty("display");
      }
      this.mounted = false;
    }
    themeName(s) {
      if (s.theme !== "auto") return s.theme;
      return this.dark ? "dark" : "default";
    }
    async produceSvg() {
      const { code, svg: svg2 } = this.source;
      this.renderedTheme = this.themeName(this.ctx.settings());
      if (code !== void 0) {
        const out = await renderMermaid(code, this.renderedTheme);
        this.diagramType = out.diagramType;
        return out.svg;
      }
      this.diagramType = svg2?.getAttribute("aria-roledescription") ?? "";
      return svg2.outerHTML;
    }
    /** Re-render if the effective theme changed (page switched dark/light, or setting changed). */
    async refreshTheme() {
      if (!this.mounted) return;
      this.dark = isDarkBehind(this.source.anchor);
      this.host.dataset.ui = this.dark ? "dark" : "light";
      this.host.style.setProperty("--ml-page-bg", pageBackground(this.host.parentElement ?? document.body));
      if (this.source.code === void 0 || this.themeName(this.ctx.settings()) === this.renderedTheme) return;
      try {
        const markup = await this.produceSvg();
        if (!this.mounted) return;
        this.setSvg(markup);
        this.applySettings(this.ctx.settings());
        this.size = { w: 0, h: 0 };
        this.lastWidth = 0;
        this.onResize();
      } catch {
      }
    }
    // ------------------------------------------------------------------ DOM
    buildUi() {
      const site = esc(this.ctx.siteName);
      const canCode = this.source.code !== void 0;
      const sequence = this.diagramType === "sequence";
      const item = (act, ic, label, sub = "", extra = "") => `<button class="item" data-act="${act}" ${extra}>${icon(ic)}<span class="label">${label}${sub ? `<span class="sub">${sub}</span>` : ""}</span></button>`;
      const slider = (key, label, lo, hi) => {
        const { min, max, step } = TIMING[key];
        return `<div class="timing"><div class="head"><h4>${label}</h4><output data-out="${key}"></output></div>
        <input type="range" data-timing="${key}" min="${min}" max="${max}" step="${step}" aria-label="${label} duration">
        <div class="scale"><span>${lo}</span><span>${hi}</span></div></div>`;
      };
      const seg = (group, opts) => `<div class="seg" role="radiogroup" data-group="${group}">${opts.map(([v, l]) => `<button role="radio" data-act="set-${group}" data-val="${v}">${l}</button>`).join("")}</div>`;
      this.root.adoptedStyleSheets = [getBaseSheet(), this.diagramSheet];
      this.root.innerHTML = `
      <div class="frame" tabindex="0" aria-label="Mermaid diagram viewer">
        <div class="viewport"></div>

        <div class="ui bar toolbar" role="toolbar" aria-label="Diagram tools">
          <button class="btn" data-act="cycle-highlight" data-state="neighbors" data-tip="Highlight: Connected (H)" aria-label="Highlight: Connected">${icon("highlight")}<span class="dot"></span></button>
          <button class="btn" data-act="toggle-flow" data-tip="Flowing edges" aria-pressed="false">${icon("waves")}</button>
          <button class="btn" data-act="replay" data-tip="Replay build-up">${icon("replay")}</button>
          <button class="btn" data-act="pop-copy" data-tip="Copy &amp; export" aria-expanded="false">${icon("copy")}</button>
          <span class="sep"></span>
          <button class="btn" data-act="fullscreen" data-tip="Full screen (F)">${icon("expand")}</button>
          <button class="btn" data-act="pop-more" data-tip="More" aria-expanded="false">${icon("more")}</button>
        </div>

        <div class="ui bar zoombar">
          <button class="btn sm" data-act="zoom-out" data-tip="Zoom out (\u2212)">${icon("minus")}</button>
          <button class="zoom-label" data-act="fit" data-tip="Fit to view (0)">100%</button>
          <button class="btn sm" data-act="zoom-in" data-tip="Zoom in (+)">${icon("plus")}</button>
          <span class="sep"></span>
          <button class="btn sm" data-act="fit" data-tip="Fit to view (0)">${icon("fit")}</button>
        </div>

        <div class="hint"></div>

        <div class="pop" data-pop="highlight" role="dialog" aria-label="Highlight options">
          <h4>Highlight</h4>
          ${seg("highlightMode", [["neighbors", "Connected"], ["flow", "Full flow"]])}
          <div class="row">
            <h4>Direction</h4>
            ${seg("direction", sequence ? [["both", "Both"], ["down", "After"], ["up", "Before"]] : [["both", "Both"], ["down", "Downstream"], ["up", "Upstream"]])}
          </div>
          <div class="row">
            <h4>Colour</h4>
            <div class="swatches">
              ${PALETTE.map((c) => `<button class="swatch" role="radio" data-act="color" data-color="${c}" aria-label="Colour ${c}"></button>`).join("")}
              <label class="custom" data-tip="Custom colour"><input type="color" aria-label="Custom colour"></label>
            </div>
          </div>
          <p class="note">${sequence ? "Hover a message, participant or alt condition. Full flow follows message order through compatible branches." : "Hover a node or arrow to light up what it connects to."} Click to pin it, <kbd>Shift</kbd>-click to pin more, <kbd>Esc</kbd> or click empty space to unpin.</p>
        </div>

        <div class="pop" data-pop="timing" role="dialog" aria-label="Animation timing">
          ${slider("flowDuration", "Flowing edges", "Fast", "Slow")}
          ${slider("buildDuration", "Build-up replay", "Quick", "Leisurely")}
          <p class="note">Flowing edges: time for one dash cycle. Build-up: roughly how long the whole diagram takes to draw.</p>
        </div>

        <div class="pop menu" data-pop="copy" role="menu">
          ${item("copy-code", "code", "Copy Mermaid code", canCode ? "" : "Source not available on this page", canCode ? "" : "disabled")}
          ${item("copy-png", "image", "Copy as image", "PNG, ready to paste")}
          ${item("copy-svg", "vector", "Copy SVG markup")}
          <div class="divider"></div>
          ${item("download-png", "download", "Download PNG")}
          ${item("download-svg", "download", "Download SVG")}
        </div>

        <div class="pop menu" data-pop="more" role="menu">
          ${item("pop-highlight", "highlight", "Highlight options", "Mode, direction and colour")}
          ${item("pop-timing", "clock", "Animation timing", "Flowing edges and build-up speed")}
          ${item("open-live", "external", "Open in Mermaid Live Editor", "", canCode ? "" : "disabled")}
          ${item("fit", "reset", "Reset view")}
          <div class="divider"></div>
          <button class="item" role="switch" data-act="disable-site" aria-checked="true">${icon("power")}<span class="label">Enabled on ${site}<span class="sub">Turn back on from the toolbar icon</span></span><span class="switch"></span></button>
        </div>

        <div class="toast" role="status" aria-live="polite"></div>
      </div>`;
      const $ = (sel) => this.root.querySelector(sel);
      this.frame = $(".frame");
      this.viewport = $(".viewport");
      this.zoomLabel = $(".zoom-label");
      this.hint = $(".hint");
      this.toastEl = $(".toast");
      this.hint.innerHTML = HINT;
      this.root.querySelectorAll(".swatch").forEach((s) => s.style.setProperty("--c", s.dataset.color));
      this.host.dataset.ui = this.dark ? "dark" : "light";
      this.host.style.setProperty("--ml-page-bg", pageBackground(this.source.anchor.parentElement ?? document.body));
      this.frame.addEventListener("click", (e) => this.onClick(e));
      this.frame.addEventListener("keydown", (e) => this.onKey(e));
      this.frame.addEventListener("pointerenter", () => this.onEnter());
      this.viewport.addEventListener("pointerdown", (e) => this.onPointerDown(e));
      this.viewport.addEventListener("pointermove", (e) => this.onPointerMove(e));
      this.viewport.addEventListener("pointerup", (e) => this.onPointerUp(e));
      this.viewport.addEventListener("pointercancel", (e) => this.onPointerUp(e));
      this.viewport.addEventListener("pointerover", (e) => this.onHover(e));
      this.viewport.addEventListener("pointerleave", () => this.setHover(null));
      this.viewport.addEventListener("wheel", (e) => this.onWheel(e), { passive: false });
      this.viewport.addEventListener("dblclick", (e) => {
        if (e.target.closest("g.node, .ml-hit, g.edgeLabel, .ml-sequence-target")) return;
        const p = this.local(e);
        this.zoomAt(e.shiftKey ? 0.5 : 2, p.x, p.y, true);
      });
      const colorInput = $(".custom input");
      colorInput.addEventListener("input", () => this.ctx.update({ highlightColor: colorInput.value }, false));
      colorInput.addEventListener("change", () => this.ctx.update({ highlightColor: colorInput.value }));
      this.root.querySelectorAll("input[data-timing]").forEach((r) => {
        const patch = () => ({ [r.dataset.timing]: Number(r.value) });
        r.addEventListener("input", () => this.ctx.update(patch(), false));
        r.addEventListener("change", () => this.ctx.update(patch()));
      });
      const onFs = () => {
        const fs = document.fullscreenElement === this.host;
        if (fs === this.fullscreen) return;
        this.fullscreen = fs;
        const btn = $('[data-act="fullscreen"]');
        btn.innerHTML = icon(fs ? "collapse" : "expand");
        btn.dataset.tip = fs ? "Exit full screen (F)" : "Full screen (F)";
        this.pristine = true;
        if (fs) this.frame.focus({ preventScroll: true });
      };
      document.addEventListener("fullscreenchange", onFs);
      this.cleanups.push(() => document.removeEventListener("fullscreenchange", onFs));
    }
    setSvg(markup) {
      const tpl = document.createElement("template");
      tpl.innerHTML = markup;
      const svg2 = tpl.content.querySelector("svg");
      if (!svg2) throw new Error("Mermaid returned no SVG");
      const styles = [...svg2.querySelectorAll("style")];
      styles.forEach((s) => s.remove());
      this.styleText = flattenStyles(svg2, styles.map((s) => s.textContent ?? "").join("\n"));
      try {
        this.diagramSheet.replaceSync(this.styleText.replace(/@import[^;]+;/g, ""));
      } catch {
      }
      const vb = (svg2.getAttribute("viewBox") ?? "").split(/[\s,]+/).map(Number);
      if (vb.length === 4 && vb.every(Number.isFinite) && vb[2] > 0 && vb[3] > 0) {
        this.natural = { x: vb[0], y: vb[1], w: vb[2], h: vb[3] };
      } else {
        const w = parseFloat(svg2.getAttribute("width") ?? "") || 600;
        const h = parseFloat(svg2.getAttribute("height") ?? "") || 400;
        this.natural = { x: 0, y: 0, w, h };
      }
      svg2.removeAttribute("style");
      svg2.removeAttribute("height");
      svg2.setAttribute("width", "100%");
      svg2.setAttribute("height", "100%");
      svg2.setAttribute("preserveAspectRatio", "xMidYMid meet");
      svg2.classList.add("ml-svg");
      this.build?.stop();
      this.viewport.replaceChildren(svg2);
      this.svg = svg2;
      this.graph = void 0;
      this.highlighter = void 0;
      this.build = new BuildAnimation(svg2);
    }
    // ------------------------------------------------------------------ settings
    applySettings(s, prev) {
      if (!this.frame) return;
      this.host.style.setProperty("--ml-hl", s.highlightColor);
      const q = (sel) => this.root.querySelectorAll(sel);
      q('[data-group="highlightMode"] button').forEach(
        (b) => b.setAttribute("aria-checked", String(b.dataset.val === s.highlightMode))
      );
      q('[data-group="direction"] button').forEach((b) => b.setAttribute("aria-checked", String(b.dataset.val === s.direction)));
      let matched = false;
      q(".swatch").forEach((b) => {
        const on = b.dataset.color.toLowerCase() === s.highlightColor.toLowerCase();
        matched ||= on;
        b.setAttribute("aria-checked", String(on));
      });
      const custom = this.root.querySelector(".custom");
      custom.setAttribute("aria-checked", String(!matched));
      const input = custom.querySelector("input");
      if (/^#[0-9a-f]{6}$/i.test(s.highlightColor)) input.value = s.highlightColor;
      q('[data-act="cycle-highlight"]').forEach((b) => {
        const state = s.highlight ? s.highlightMode : "off";
        if (b.dataset.state !== state) {
          b.dataset.state = state;
          b.innerHTML = `${icon(state === "flow" ? "flow" : "highlight")}<span class="dot"></span>`;
        }
        b.classList.toggle("on", s.highlight);
        b.dataset.tip = `Highlight: ${HL_LABEL[state]} (H)`;
        b.setAttribute("aria-label", `Highlight: ${HL_LABEL[state]}`);
      });
      q('[data-act="toggle-flow"]').forEach((b) => {
        b.classList.toggle("on", s.flowAnimation);
        b.setAttribute("aria-pressed", String(s.flowAnimation));
        b.dataset.tip = s.flowAnimation ? "Flowing edges: on" : "Flowing edges: off";
      });
      this.host.style.setProperty("--ml-flow-duration", `${s.flowDuration}s`);
      for (const key of Object.keys(TIMING)) {
        q(`input[data-timing="${key}"]`).forEach((r) => r.value = String(s[key]));
        q(`output[data-out="${key}"]`).forEach((o) => o.textContent = secs(s[key]));
      }
      this.svg?.classList.toggle("ml-flowing", s.flowAnimation);
      this.svg?.classList.toggle("ml-hl-enabled", s.highlight);
      this.highlighter?.configure(s.highlight, s.highlightMode, s.direction);
      if (prev && prev.theme !== s.theme) void this.refreshTheme();
    }
    // ------------------------------------------------------------------ geometry
    onResize() {
      const w = this.viewport.clientWidth;
      if (!w) return;
      if (!this.fullscreen && w !== this.lastWidth) {
        this.lastWidth = w;
        const h = this.inlineHeight(w);
        if (Math.abs(h - this.frame.offsetHeight) > 1) {
          this.frame.style.height = `${h}px`;
          return;
        }
      }
      const prev = this.size;
      this.size = { w, h: this.viewport.clientHeight };
      if (this.pristine || !prev.w) {
        this.fit();
      } else {
        const { k } = this.view;
        const cx = (prev.w / 2 - this.view.x) / k;
        const cy = (prev.h / 2 - this.view.y) / k;
        this.view.x = this.size.w / 2 - cx * k;
        this.view.y = this.size.h / 2 - cy * k;
        this.applyView();
      }
      if (this.graph === void 0) this.ensureGraph();
    }
    inlineHeight(width) {
      const scale = Math.min(1, (width - PAD * 2) / this.natural.w);
      const maxH = Math.max(320, Math.min(window.innerHeight * 0.8, 900));
      return Math.round(clamp(this.natural.h * scale + PAD * 2, MIN_HEIGHT, maxH));
    }
    get fitScale() {
      const { w, h } = this.size;
      return Math.min((w - PAD * 2) / this.natural.w, (h - PAD * 2) / this.natural.h, this.fullscreen ? 2.5 : 1);
    }
    fit() {
      if (!this.size.w) return;
      const k = Math.max(0.02, this.fitScale);
      const { w, h } = this.size;
      this.view = {
        k,
        x: (w - this.natural.w * k) / 2 - this.natural.x * k,
        y: (h - this.natural.h * k) / 2 - this.natural.y * k
      };
      this.pristine = true;
      this.applyView();
    }
    applyView() {
      if (!this.svg) return;
      const { x, y, k } = this.view;
      const { w, h } = this.size;
      this.svg.setAttribute("viewBox", `${-x / k} ${-y / k} ${w / k} ${h / k}`);
      this.zoomLabel.textContent = `${Math.round(k * 100)}%`;
    }
    zoomAt(factor, px, py, animate = false) {
      const k0 = this.view.k;
      const k = clamp(k0 * factor, Math.min(0.05, this.fitScale * 0.5), 12);
      const f = k / k0;
      const target = { k, x: px - (px - this.view.x) * f, y: py - (py - this.view.y) * f };
      this.pristine = false;
      if (animate) this.animateTo(target);
      else {
        this.view = target;
        this.applyView();
      }
    }
    zoomBy(factor) {
      this.zoomAt(factor, this.size.w / 2, this.size.h / 2, true);
    }
    animateTo(target) {
      const from = { ...this.view };
      const t0 = performance.now();
      const step = (t) => {
        const p = Math.min(1, (t - t0) / 180);
        const e = 1 - Math.pow(1 - p, 3);
        this.view = {
          x: from.x + (target.x - from.x) * e,
          y: from.y + (target.y - from.y) * e,
          k: from.k + (target.k - from.k) * e
        };
        this.applyView();
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }
    local(e) {
      const r = this.viewport.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    }
    // ------------------------------------------------------------------ input
    onEnter() {
      this.ensureGraph();
      if (performance.now() - this.hintShownAt > 6e4) this.flashHint(null, 4e3);
    }
    flashHint(html2, ms = 1800) {
      this.hint.innerHTML = html2 ?? HINT;
      this.hintShownAt = performance.now();
      this.hint.classList.add("show");
      clearTimeout(this.hintTimer);
      this.hintTimer = window.setTimeout(() => this.hint.classList.remove("show"), ms);
    }
    onPointerDown(e) {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      this.closePop();
      this.frame.dataset.pointer = "";
      this.frame.focus({ preventScroll: true });
      this.viewport.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.pointers.size === 1) {
        this.drag = { sx: e.clientX, sy: e.clientY, x0: this.view.x, y0: this.view.y, moved: false, target: e.target };
      } else if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        const mid = this.local({ clientX: (a.x + b.x) / 2, clientY: (a.y + b.y) / 2 });
        this.pinch = { d0: Math.hypot(a.x - b.x, a.y - b.y), k0: this.view.k, cx: mid.x, cy: mid.y, x0: this.view.x, y0: this.view.y };
        if (this.drag) this.drag.moved = true;
      }
    }
    onPointerMove(e) {
      if (!this.pointers.has(e.pointerId)) return;
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.pinch && this.pointers.size >= 2) {
        const [a, b] = [...this.pointers.values()];
        const d2 = Math.hypot(a.x - b.x, a.y - b.y);
        const k = clamp(this.pinch.k0 * d2 / this.pinch.d0, 0.05, 12);
        const f = k / this.pinch.k0;
        const mid = this.local({ clientX: (a.x + b.x) / 2, clientY: (a.y + b.y) / 2 });
        this.view = {
          k,
          x: mid.x - (this.pinch.cx - this.pinch.x0) * f,
          y: mid.y - (this.pinch.cy - this.pinch.y0) * f
        };
        this.pristine = false;
        this.applyView();
        return;
      }
      const d = this.drag;
      if (!d) return;
      const dx = e.clientX - d.sx;
      const dy = e.clientY - d.sy;
      if (!d.moved && Math.hypot(dx, dy) > 4) {
        d.moved = true;
        this.viewport.classList.add("grabbing");
      }
      if (d.moved) {
        this.view.x = d.x0 + dx;
        this.view.y = d.y0 + dy;
        this.pristine = false;
        this.applyView();
      }
    }
    onPointerUp(e) {
      if (!this.pointers.delete(e.pointerId)) return;
      if (this.pointers.size === 0) {
        if (this.drag && !this.drag.moved && e.type === "pointerup") this.onTap(this.drag.target, e);
        this.drag = void 0;
        this.pinch = void 0;
        this.viewport.classList.remove("grabbing");
      } else if (this.pointers.size === 1) {
        const [p] = [...this.pointers.values()];
        this.pinch = void 0;
        this.drag = { sx: p.x, sy: p.y, x0: this.view.x, y0: this.view.y, moved: true, target: null };
      }
    }
    onWheel(e) {
      const zoomGesture = e.ctrlKey || e.metaKey;
      if (!zoomGesture && !this.fullscreen) {
        if (performance.now() - this.hintShownAt > 2500) this.flashHint(`Hold <kbd>${MOD}</kbd> and scroll to zoom`);
        return;
      }
      e.preventDefault();
      const p = this.local(e);
      const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 400 : 1;
      const dy = e.deltaY * unit;
      const mouseWheel = e.deltaMode !== 0 || e.deltaX === 0 && Math.abs(e.deltaY) >= 40 && Number.isInteger(e.deltaY);
      if (zoomGesture || mouseWheel) {
        const rate = zoomGesture && Math.abs(dy) < 50 ? 0.01 : 2e-3;
        this.zoomAt(Math.exp(-dy * rate), p.x, p.y);
      } else {
        this.view.x -= e.deltaX * unit;
        this.view.y -= dy;
        this.pristine = false;
        this.applyView();
      }
    }
    onKey(e) {
      delete this.frame.dataset.pointer;
      if (e.target instanceof HTMLInputElement || e.altKey || e.ctrlKey || e.metaKey) return;
      const pan = (dx, dy) => {
        this.view.x += dx;
        this.view.y += dy;
        this.pristine = false;
        this.applyView();
      };
      switch (e.key) {
        case "+":
        case "=":
          this.zoomBy(1.25);
          break;
        case "-":
        case "_":
          this.zoomBy(0.8);
          break;
        case "0":
          this.fit();
          break;
        case "f":
        case "F":
          void this.toggleFullscreen();
          break;
        case "h":
        case "H":
          this.cycleHighlight();
          break;
        case "Escape":
          if (this.openPop) this.closePop();
          else if (this.highlighter?.active) this.highlighter.clear();
          else return;
          break;
        case "ArrowLeft":
          pan(60, 0);
          break;
        case "ArrowRight":
          pan(-60, 0);
          break;
        case "ArrowUp":
          pan(0, 60);
          break;
        case "ArrowDown":
          pan(0, -60);
          break;
        default:
          return;
      }
      e.preventDefault();
      e.stopPropagation();
    }
    // ------------------------------------------------------------------ highlight
    ensureGraph() {
      if (this.graph !== void 0 || !this.svg) return this.graph ?? null;
      if (!this.viewport.clientWidth) return null;
      this.graph = this.diagramType === "sequence" ? extractSequence(this.svg) : extractGraph(this.svg);
      if (this.graph) {
        const s = this.ctx.settings();
        this.highlighter = new Highlighter(this.svg, this.graph, s.highlight, s.highlightMode, s.direction);
      }
      return this.graph;
    }
    onHover(e) {
      if (e.pointerType === "touch" || this.pointers.size || !this.ctx.settings().highlight) return;
      const graph = this.ensureGraph();
      if (!graph || !(e.target instanceof Element)) return;
      this.setHover(this.hitTest(e.target, graph));
    }
    setHover(item) {
      clearTimeout(this.hoverTimer);
      if (item) this.highlighter?.hover(item);
      else this.hoverTimer = window.setTimeout(() => this.highlighter?.hover(null), HOVER_OUT_MS);
    }
    /** Toolbar button / H: Connected → Full flow → Off → Connected. */
    cycleHighlight() {
      const s = this.ctx.settings();
      const patch = !s.highlight ? { highlight: true, highlightMode: "neighbors" } : s.highlightMode === "neighbors" ? { highlightMode: "flow" } : { highlight: false };
      this.ctx.update(patch);
      const next = { ...s, ...patch };
      this.toast(`Highlight: ${HL_LABEL[next.highlight ? next.highlightMode : "off"]}`);
    }
    onTap(target, e) {
      const s = this.ctx.settings();
      if (!s.highlight || !(target instanceof Element)) return;
      const graph = this.ensureGraph();
      if (!graph || !this.highlighter) return;
      const item = this.hitTest(target, graph);
      if (item) this.highlighter.select(item, e.shiftKey || e.metaKey || e.ctrlKey);
      else this.highlighter.clear();
    }
    hitTest(target, graph) {
      const el = target.closest(".ml-hit, g.node, g.edgeLabel, .cluster-label, .ml-sequence-target");
      if (!el) return null;
      if (el.matches(".cluster-label")) {
        const cluster = el.closest("g.cluster");
        return cluster && graph.byElement.get(cluster) || null;
      }
      return graph.byElement.get(el) ?? null;
    }
    // ------------------------------------------------------------------ toolbar actions
    onClick(e) {
      const btn = e.target.closest("[data-act]");
      if (!btn || btn.hasAttribute("disabled")) return;
      const act = btn.dataset.act;
      if (act.startsWith("pop-")) {
        const name = act.slice(4);
        const anchor = btn.closest(".pop") ? this.root.querySelector(`[data-act="pop-${this.openPop}"]`) : btn;
        if (this.openPop === name) this.closePop();
        else this.showPop(name, anchor);
        return;
      }
      const s = this.ctx.settings();
      switch (act) {
        case "cycle-highlight":
          this.cycleHighlight();
          break;
        case "set-highlightMode":
          this.ctx.update({ highlightMode: btn.dataset.val });
          break;
        case "set-direction":
          this.ctx.update({ direction: btn.dataset.val });
          break;
        case "color":
          this.ctx.update({ highlightColor: btn.dataset.color });
          break;
        case "toggle-flow":
          this.ctx.update({ flowAnimation: !s.flowAnimation });
          break;
        case "replay":
          this.closePop();
          this.replay();
          break;
        case "zoom-in":
          this.zoomBy(1.25);
          break;
        case "zoom-out":
          this.zoomBy(0.8);
          break;
        case "fit":
          this.closePop();
          this.fit();
          break;
        case "fullscreen":
          void this.toggleFullscreen();
          break;
        case "copy-code":
          this.closePop();
          copyText(this.source.code ?? "").then(
            () => this.toast("Mermaid code copied"),
            () => this.toast("Couldn\u2019t access the clipboard")
          );
          break;
        case "copy-svg":
          this.closePop();
          copyText(serializeSvg(this.exportSource())).then(
            () => this.toast("SVG copied"),
            () => this.toast("Couldn\u2019t access the clipboard")
          );
          break;
        case "copy-png":
          this.closePop();
          copyPng(svgToPng(this.exportSource())).then(
            () => this.toast("Image copied"),
            (err) => {
              console.debug("[Mermaid Lens] image copy failed", err);
              this.toast("Couldn\u2019t copy the image");
            }
          );
          break;
        case "download-png":
          this.closePop();
          svgToPng(this.exportSource()).then(
            (png) => download(`${this.fileName()}.png`, png),
            () => this.toast("Couldn\u2019t create the image")
          );
          break;
        case "download-svg":
          this.closePop();
          download(`${this.fileName()}.svg`, serializeSvg(this.exportSource()));
          break;
        case "open-live":
          this.closePop();
          window.open(mermaidLiveUrl(this.source.code ?? "", this.renderedTheme), "_blank", "noopener");
          break;
        case "disable-site":
          this.ctx.disableSite();
          break;
      }
    }
    replay() {
      const svg2 = this.svg;
      if (!svg2 || !this.build) return;
      const flowing = svg2.classList.contains("ml-flowing");
      svg2.classList.remove("ml-flowing");
      const s = this.ctx.settings();
      this.build.play(
        this.diagramType === "sequence" ? null : this.ensureGraph(),
        () => svg2.classList.toggle("ml-flowing", this.ctx.settings().flowAnimation),
        s.buildDuration / BASE_BUILD_SECONDS
      );
      if (flowing) this.toast("Replaying\u2026");
    }
    exportSource() {
      return {
        svg: this.svg,
        styleText: this.styleText,
        natural: this.natural,
        background: pageBackground(this.host.parentElement ?? document.body)
      };
    }
    fileName() {
      const type = (this.diagramType || "diagram").replace(/[^a-z0-9]+/gi, "-").replace(/-v\d+$/, "");
      return `mermaid-${type}`;
    }
    async toggleFullscreen() {
      try {
        if (document.fullscreenElement === this.host) await document.exitFullscreen();
        else await this.host.requestFullscreen({ navigationUI: "hide" });
      } catch {
        this.toast("Full screen isn\u2019t available here");
      }
    }
    showPop(name, btn) {
      this.closePop();
      const pop = this.root.querySelector(`[data-pop="${name}"]`);
      const fr = this.frame.getBoundingClientRect();
      const br = btn.getBoundingClientRect();
      pop.style.right = `${Math.max(10, fr.right - br.right - 6)}px`;
      pop.classList.add("open");
      btn.setAttribute("aria-expanded", "true");
      this.frame.classList.add("engaged");
      this.openPop = name;
      this.popAnchor = btn;
      const outside = (ev) => {
        if (!ev.composedPath().some((n) => n === pop || n === btn)) this.closePop();
      };
      setTimeout(() => document.addEventListener("pointerdown", outside, true));
      this.popCleanup = () => document.removeEventListener("pointerdown", outside, true);
    }
    popCleanup;
    popAnchor;
    closePop() {
      if (!this.openPop) return;
      this.root.querySelector(`[data-pop="${this.openPop}"]`)?.classList.remove("open");
      this.popAnchor?.setAttribute("aria-expanded", "false");
      this.popAnchor = void 0;
      this.frame.classList.remove("engaged");
      this.popCleanup?.();
      this.popCleanup = void 0;
      this.openPop = void 0;
    }
    toast(message) {
      this.toastEl.innerHTML = `${icon("check")}<span></span>`;
      this.toastEl.querySelector("span").textContent = message;
      this.toastEl.classList.add("show");
      clearTimeout(this.toastTimer);
      this.toastTimer = window.setTimeout(() => this.toastEl.classList.remove("show"), 1800);
    }
  };

  // src/enhancer/index.ts
  var MermaidLens = class {
    settings;
    enabled = false;
    viewers = /* @__PURE__ */ new Map();
    managed = /* @__PURE__ */ new Set();
    observer;
    scanTimer = 0;
    themeTimer = 0;
    reported = "";
    host = location.hostname;
    ctx = {
      settings: () => this.settings,
      update: (patch, persist = true) => {
        this.onSettings({ ...this.settings, ...patch });
        if (persist) void saveSettings(patch);
      },
      disableSite: () => {
        this.setEnabled(false);
        void setSiteEnabled(this.host, false);
      },
      siteName: this.host
    };
    async init() {
      this.settings = await loadSettings();
      watchSettings((s) => this.onSettings(s));
      this.watchTheme();
      this.setEnabled(isSiteEnabled(this.settings, this.host));
    }
    onSettings(next) {
      const prev = this.settings;
      this.settings = next;
      this.setEnabled(isSiteEnabled(next, this.host));
      for (const v of this.viewers.values()) v.applySettings(next, prev);
    }
    setEnabled(on) {
      if (on !== this.enabled) {
        this.enabled = on;
        if (on) this.start();
        else this.stop();
      }
      this.report();
    }
    start() {
      this.observer = new MutationObserver(() => {
        if (!this.scanTimer) this.scanTimer = window.setTimeout(() => this.scan(), 200);
      });
      this.observer.observe(document.documentElement, { childList: true, subtree: true });
      this.scan();
    }
    stop() {
      this.observer?.disconnect();
      clearTimeout(this.scanTimer);
      this.scanTimer = 0;
      for (const v of this.viewers.values()) v.destroy();
      this.viewers.clear();
      this.managed.clear();
    }
    scan() {
      this.scanTimer = 0;
      if (!this.enabled) return;
      for (const [anchor, v] of this.viewers) {
        if (v.mounted && (!anchor.isConnected || !v.host.isConnected)) {
          v.destroy();
          this.viewers.delete(anchor);
          this.managed.delete(anchor);
        }
      }
      for (const anchor of this.managed) {
        if (!anchor.isConnected && !this.viewers.has(anchor)) this.managed.delete(anchor);
      }
      for (const source of findDiagrams(this.managed)) {
        const viewer = new DiagramViewer(source, this.ctx);
        this.viewers.set(source.anchor, viewer);
        viewer.mount().then((ok) => {
          if (!ok || !this.enabled) {
            this.viewers.delete(source.anchor);
            if (ok) viewer.destroy();
          }
          this.report();
        });
      }
      this.report();
    }
    watchTheme() {
      const refresh = () => {
        clearTimeout(this.themeTimer);
        this.themeTimer = window.setTimeout(() => {
          for (const v of this.viewers.values()) void v.refreshTheme();
        }, 150);
      };
      new MutationObserver(refresh).observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-color-mode", "data-dark-theme", "data-light-theme", "data-theme", "class", "style"]
      });
      if (document.body) {
        new MutationObserver(refresh).observe(document.body, { attributes: true, attributeFilter: ["class", "data-theme", "style"] });
      }
      matchMedia("(prefers-color-scheme: dark)").addEventListener("change", refresh);
    }
    report() {
      const count = [...this.viewers.values()].filter((v) => v.mounted).length;
      const key = `${this.enabled}:${count}`;
      if (key === this.reported) return;
      this.reported = key;
      const msg = { type: "ml:status", count, enabled: this.enabled };
      chrome.runtime.sendMessage(msg).catch(() => {
      });
    }
  };
  if (!window.__mermaidLens) {
    const lens = new MermaidLens();
    window.__mermaidLens = lens;
    void lens.init();
  }
})();
